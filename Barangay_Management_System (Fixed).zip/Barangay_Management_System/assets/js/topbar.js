document.addEventListener('DOMContentLoaded', () => {
  const root = document.getElementById('adminDropdown');
  const toggle = document.getElementById('adminDropdownToggle');
  const menu = document.getElementById('adminDropdownMenu');
  if (root && toggle && menu) {
    const close = () => { menu.hidden = true; toggle.setAttribute('aria-expanded', 'false'); };
    toggle.addEventListener('click', () => { const open = menu.hidden; menu.hidden = !open; toggle.setAttribute('aria-expanded', String(open)); });
    document.addEventListener('click', event => { if (!root.contains(event.target)) close(); });
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && !menu.hidden) { close(); toggle.focus(); } });
  }
  const mobileToggle = document.getElementById('menuToggle');
  const sidebar = document.getElementById('sidebar');
  if (mobileToggle && sidebar) {
    mobileToggle.addEventListener('click', () => { const open = sidebar.classList.toggle('open'); mobileToggle.setAttribute('aria-expanded', String(open)); });
    document.addEventListener('click', event => { if (!sidebar.contains(event.target) && !mobileToggle.contains(event.target)) { sidebar.classList.remove('open'); mobileToggle.setAttribute('aria-expanded', 'false'); } });
  }
});
