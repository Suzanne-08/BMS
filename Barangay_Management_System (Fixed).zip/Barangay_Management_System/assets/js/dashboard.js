document.addEventListener('DOMContentLoaded', function() {

    // Mobile sidebar
    const toggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');

    if (toggle && sidebar) {
        toggle.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });

        document.addEventListener('click', (event) => {
            if (
                sidebar.classList.contains('open') &&
                !sidebar.contains(event.target) &&
                !toggle.contains(event.target)
            ) {
                sidebar.classList.remove('open');
            }
        });
    }

    if (typeof Chart === 'undefined' || !window.dashboardData) {
        console.error('Chart.js or dashboard data is unavailable.');
        return;
    }

    const data = window.dashboardData;

    Chart.defaults.font.family = 'Inter, Arial, sans-serif';
    Chart.defaults.color = '#405a83';

    // Certificate Requests Chart

    const certificateCanvas =
        document.getElementById('certificateChart');

    if (certificateCanvas) {
        new Chart(certificateCanvas, {
            type: 'bar',
            data: {
                labels: data.certificate.labels,
                datasets: [{
                        label: 'Pending',
                        data: data.certificate.pending,
                        backgroundColor: '#ffb400',
                        borderRadius: 3
                    },
                    {
                        label: 'Processing',
                        data: data.certificate.processing,
                        backgroundColor: '#1683ff',
                        borderRadius: 3
                    },
                    {
                        label: 'Released',
                        data: data.certificate.released,
                        backgroundColor: '#22b573',
                        borderRadius: 3
                    },
                    {
                        label: 'Other Statuses',
                        data: data.certificate.other,
                        backgroundColor: '#8b5cf6',
                        borderRadius: 3
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            usePointStyle: true,
                            boxWidth: 9,
                            font: { size: 11 }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: {
                            font: { size: 10 },
                            maxRotation: 45
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: { precision: 0 },
                        grid: { color: '#e6edf7' }
                    }
                }
            }
        });
    }

    // Request Status Donut

    const statusCanvas = document.getElementById('statusChart');

    if (statusCanvas) {
        new Chart(statusCanvas, {
            type: 'doughnut',
            data: {
                labels: data.status.labels,
                datasets: [{
                    data: data.status.values,
                    backgroundColor: [
                        '#ffb400',
                        '#1683ff',
                        '#8b5cf6',
                        '#22b573',
                        '#ef4444'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '72%',
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }

    // Payment Methods Donut

    const paymentCanvas = document.getElementById('paymentChart');

    if (paymentCanvas) {
        new Chart(paymentCanvas, {
            type: 'doughnut',
            data: {
                labels: data.payments.labels,
                datasets: [{
                    data: data.payments.values,
                    backgroundColor: [
                        '#1683ff',
                        '#22b573',
                        '#8b5cf6',
                        '#ffb400',
                        '#ef4444',
                        '#06b6d4'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '72%',
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }
});