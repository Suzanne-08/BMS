<?php
// Shared administrator header. Include this inside .main-wrapper after sidebar.
$pageTitle = isset($pageTitle) ? (string) $pageTitle : 'Dashboard';
$adminDisplayName = (string) ($_SESSION['admin_name'] ?? ($currentUser['full_name'] ?? 'System Administrator'));
$pendingTopbar = isset($statusCounts['pending']) ? (int) $statusCounts['pending'] : 0;
if (!isset($statusCounts) && isset($pdo) && $pdo instanceof PDO) {
    $pendingTopbar = (int) $pdo->query("SELECT COUNT(*) FROM certificate_requests WHERE status = 'pending'")->fetchColumn();
}
$topbarSearch = trim((string) ($_GET['search'] ?? ''));
?>
<header class="topbar" id="sharedAdminTopbar">
    <button class="menu-toggle" id="menuToggle" type="button" aria-label="Toggle navigation" aria-expanded="false" aria-controls="sidebar">
        <i class="fa-solid fa-bars" aria-hidden="true"></i>
    </button>
    <form method="GET" action="dashboard.php" class="search-box" role="search">
        <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
        <input type="search" name="search" placeholder="Search resident, request, reference no..."
               value="<?= htmlspecialchars($topbarSearch, ENT_QUOTES, 'UTF-8') ?>" aria-label="Search requests">
        <button type="submit" aria-label="Search"><i class="fa-solid fa-arrow-right"></i></button>
    </form>
    <div class="topbar-right">
        <a class="notification-icon" href="certificates.php" title="Pending certificate requests" aria-label="Pending certificate requests: <?= $pendingTopbar ?>">
            <i class="fa-regular fa-bell" aria-hidden="true"></i>
            <?php if ($pendingTopbar > 0): ?>
                <span class="notification-count"><?= $pendingTopbar > 99 ? '99+' : $pendingTopbar ?></span>
            <?php endif; ?>
        </a>
        <div class="admin-dropdown" id="adminDropdown">
            <button type="button" class="admin-dropdown-toggle" id="adminDropdownToggle" aria-expanded="false" aria-controls="adminDropdownMenu" aria-haspopup="true">
                <span class="profile-avatar"><i class="fa-solid fa-user" aria-hidden="true"></i></span>
                <span class="profile-info"><strong><?= htmlspecialchars($adminDisplayName, ENT_QUOTES, 'UTF-8') ?></strong><small>Barangay Administrator</small></span>
                <i class="fa-solid fa-chevron-down dropdown-chevron" aria-hidden="true"></i>
            </button>
            <div class="admin-dropdown-menu" id="adminDropdownMenu" hidden>
                <div class="dropdown-heading">Administrator Account</div>
                <a href="../logout.php" class="dropdown-logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
            </div>
        </div>
    </div>
</header>
