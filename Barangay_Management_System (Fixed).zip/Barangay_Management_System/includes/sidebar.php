<?php
$base = '/Barangay_Management_System';
$currentPage = basename($_SERVER['SCRIPT_NAME'] ?? '');
$menuItems = [
    ['dashboard.php', 'fa-house', 'Dashboard'],
    ['certificates.php', 'fa-file-lines', 'Certificate Requests'],
    ['residents.php', 'fa-users', 'Resident Management'],
    ['issued_certificates.php', 'fa-certificate', 'Issuance & Records'],
    ['payments.php', 'fa-credit-card', 'E-Payment'],
    ['sms_notifications.php', 'fa-comment-sms', 'SMS Notifications'],
    ['tracking.php', 'fa-location-dot', 'Tracking'],
    ['reports.php', 'fa-chart-column', 'Reports']
];
?>
<aside class="sidebar" id="sidebar">
    <div class="brand">
        <div class="brand-logo"><i class="fa-solid fa-building-columns"></i></div>
        <div class="brand-text">
            <strong>Barangay Management</strong>
            <span>and Certificate Issuance System</span>
            <small>with SMS Notification, Tracking and E-Payment</small>
        </div>
    </div>
    <nav class="sidebar-nav" aria-label="Admin navigation">
        <?php foreach ($menuItems as $item): ?>
            <a href="<?= htmlspecialchars($base . '/admin/' . $item[0], ENT_QUOTES, 'UTF-8') ?>"
               class="nav-item <?= $currentPage === $item[0] ? 'active' : '' ?>"
               <?= $currentPage === $item[0] ? 'aria-current="page"' : '' ?>>
                <i class="fa-solid <?= htmlspecialchars($item[1], ENT_QUOTES, 'UTF-8') ?>" aria-hidden="true"></i>
                <span><?= htmlspecialchars($item[2], ENT_QUOTES, 'UTF-8') ?></span>
            </a>
        <?php endforeach; ?>
    </nav>
</aside>
