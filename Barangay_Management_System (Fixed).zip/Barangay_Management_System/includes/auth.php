<?php
declare(strict_types=1);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check admin authentication
if (empty($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit;
}

// Load database connection
require_once __DIR__ . '/../config/database.php';

// Get logged-in administrator
$stmt = $pdo->prepare("
    SELECT id, username, full_name, role, status
    FROM users
    WHERE id = ?
      AND role = 'admin'
      AND status = 'active'
    LIMIT 1
");

$stmt->execute([$_SESSION['admin_id']]);

$currentUser = $stmt->fetch(PDO::FETCH_ASSOC);

// Invalid or inactive admin
if (!$currentUser) {
    $_SESSION = [];
    session_destroy();

    header('Location: ../login.php');
    exit;
}

// Secure HTML output
if (!function_exists('e')) {
    function e($value): string
    {
        return htmlspecialchars(
            (string) ($value ?? ''),
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8'
        );
    }
}
