<?php
declare(strict_types=1);

require_once __DIR__ . '/../../includes/session.php';
require_once __DIR__ . '/../../config/database.php';

if (
    empty($_SESSION['user_id'])
    || ($_SESSION['role'] ?? '') !== 'resident'
    || empty($_SESSION['resident_id'])
) {
    header('Location: /Barangay_Management_System/login.php');
    exit;
}

$stmt = $pdo->prepare(
    "SELECT u.id, u.full_name, r.id AS resident_id, r.resident_no
     FROM users u
     JOIN resident_accounts ra ON ra.user_id = u.id
     JOIN residents r ON r.id = ra.resident_id
     WHERE u.id = ?
       AND r.id = ?
       AND u.role = 'resident'
       AND u.status = 'active'
     LIMIT 1"
);

$stmt->execute([
    (int) $_SESSION['user_id'],
    (int) $_SESSION['resident_id'],
]);

$currentResident = $stmt->fetch();

if (!$currentResident) {
    $_SESSION = [];
    session_destroy();
    header('Location: ../../login.php');
exit;
}