<?php
require '../includes/auth.php';
require '../config/database.php';

function countq($pdo, $sql)
{
    return (int) $pdo->query($sql)->fetchColumn();
}

$s = [
    'residents' => countq($pdo, "SELECT COUNT(*) FROM residents"),
    'senior' => countq($pdo, "SELECT COUNT(*) FROM residents WHERE senior_citizen = 1"),
    'pwd' => countq($pdo, "SELECT COUNT(*) FROM residents WHERE pwd = 1"),
    'solo' => countq($pdo, "SELECT COUNT(*) FROM residents WHERE solo_parent = 1"),
    'fourps' => countq($pdo, "SELECT COUNT(*) FROM residents WHERE four_ps = 1"),
    'farmers' => countq($pdo, "SELECT COUNT(*) FROM residents WHERE farmer = 1"),
    'households' => countq(
        $pdo,
        "SELECT COUNT(DISTINCT household_no)
         FROM residents
         WHERE household_no IS NOT NULL
           AND household_no <> ''"
    ),
];
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="app">
        <?php include '../includes/sidebar.php'; ?>

        <main class="content">
            <header class="top">
                <input placeholder="Search resident, request, reference no...">
                <div>
                    🔔 &nbsp;
                    <b><?= htmlspecialchars($_SESSION['admin_name']) ?></b>
                </div>
            </header>

            <section class="page">
                <div class="page-head">
                    <div>
                        <h1>Dashboard Overview</h1>
                        <p>Resident Management Summary</p>
                    </div>
                    <a class="primary" href="residents.php?action=add">+ Add Resident</a>
                </div>

                <div class="counter-grid">
                    <?php foreach ([
                        ['Total Residents', $s['residents'], '👥'],
                        ['Senior Citizens', $s['senior'], '👴'],
                        ['PWD', $s['pwd'], '♿'],
                        ['Solo Parents', $s['solo'], '👤'],
                        ['4Ps Beneficiaries', $s['fourps'], '🤝'],
                        ['Farmers', $s['farmers'], '🌾'],
                        ['Households', $s['households'], '🏠'],
                    ] as $x): ?>
                        <article class="counter">
                            <span><?= $x[2] ?></span>
                            <div>
                                <strong><?= $x[1] ?></strong>
                                <small><?= $x[0] ?></small>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>

                <div class="module-grid">
                    <section class="panel">
                        <h2>👤 Resident Management</h2>
                        <div class="module-links">
                            <a href="residents.php?action=add">Add Resident Record</a>
                            <a href="residents.php">Update / Search Resident</a>
                            <a href="residents.php">View Resident Profile</a>
                        </div>
                    </section>

                    <section class="panel">
                        <h2>📜 Certificate Management</h2>
                        <div class="module-links">
                            <a href="certificates.php">Certificate Requests</a>
                            <a href="certificates.php?status=processing">Certificate Processing</a>
                            <a href="certificates.php?status=approval">Certificate Approval</a>
                            <a href="certificates.php?status=generation">Certificate Generation</a>
                            <a href="certificates.php?status=released">Release Tracking</a>
                        </div>
                    </section>

                    <section class="panel">
                        <h2>📱 SMS Notification</h2>
                        <div class="module-links">
                            <a href="sms.php">Request Confirmation Alerts</a>
                            <a href="sms.php">Processing Status Updates</a>
                            <a href="sms.php">Ready-for-Release Notifications</a>
                        </div>
                    </section>

                    <section class="panel">
                        <h2>📈 Reports &amp; Records</h2>
                        <div class="module-links">
                            <a href="reports.php#resident">Resident Reports</a>
                            <a href="reports.php#certificate">Certificate Reports</a>
                            <a href="reports.php#transaction">Transaction Reports</a>
                            <a href="reports.php#sms">SMS Notification Records</a>
                        </div>
                    </section>
                </div>
            </section>
        </main>
    </div>
</body>
</html>