BARANGAY MANAGEMENT AND CERTIFICATE ISSUANCE SYSTEM - ADMIN

XAMPP SETUP
1. Copy the barangay-system folder to C:\xampp\htdocs\
2. Start Apache and MySQL in XAMPP.
3. For a fresh installation, import database/barangay_system.sql in phpMyAdmin.
4. Open http://localhost/barangay-system/
5. Login: admin / Admin123!

IMPORTANT FOR AN EXISTING STARTER DATABASE:
The SQL file now includes ALTER TABLE statements that add the expanded Resident Management fields. You may import the updated SQL into the existing barangay_system database, or recreate the database for a clean demo.

ADMIN MODULES INCLUDED
- Dashboard Overview with real-time resident counters
- Resident Management: Add, Update, Search, View Profile, Delete
- Classification tags: Senior Citizen, PWD, Solo Parent, 4Ps, Farmer
- Household tracking
- Certificate Management workflow/status controls
- SMS Notification records panel
- Reports & Records summary

SMS is represented as database notification records in this local XAMPP version. A live SMS provider API can be connected later.
