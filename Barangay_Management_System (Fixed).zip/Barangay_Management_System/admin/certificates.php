<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
if (!isset($pdo) || !($pdo instanceof PDO)) { http_response_code(500); exit('Database connection unavailable.'); }
if (!function_exists('e')) { function e($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); } }
if (empty($_SESSION['certificate_csrf'])) { $_SESSION['certificate_csrf'] = bin2hex(random_bytes(32)); }
$allowed = ['pending'=>'processing', 'processing'=>'for_release'];
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = (string)($_POST['csrf'] ?? '');
    if (!hash_equals($_SESSION['certificate_csrf'], $token)) { http_response_code(403); exit('Invalid request token.'); }
    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
    $target = (string)($_POST['status'] ?? '');
    if (!$id || !in_array($target, array_values($allowed), true)) { $error = 'Invalid action.'; }
    else {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare('SELECT status FROM certificate_requests WHERE id = ? FOR UPDATE');
            $stmt->execute([$id]);
            $existing = $stmt->fetchColumn();
            if ($existing === false || ($allowed[$existing] ?? null) !== $target) {
                $pdo->rollBack(); $error = 'This request has changed status. Refresh and try again.';
            } else {
                $stmt = $pdo->prepare('UPDATE certificate_requests SET status = ? WHERE id = ? AND status = ?');
                $stmt->execute([$target, $id, $existing]);
                if ($stmt->rowCount() !== 1) { throw new RuntimeException('Request status changed.'); }
                $remarks = $target === 'processing'
                    ? 'Administrator started processing the certificate request.'
                    : 'Administrator approved the request for issuance.';
                $history = $pdo->prepare('INSERT INTO request_status_history
                    (request_id, old_status, new_status, remarks, changed_by, changed_at)
                    VALUES (?, ?, ?, ?, ?, NOW())');
                $history->execute([$id, $existing, $target, $remarks, (int) $_SESSION['admin_id']]);
                $pdo->commit();
                header('Location: certificates.php?updated=1', true, 303); exit;
            }
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('Certificate status update: ' . $ex->getMessage());
            $error = 'Unable to update request. Check the server log.';
        }
    }
}
$rows = $pdo->query('SELECT c.id, c.reference_no, c.certificate_type, c.purpose, c.status, c.created_at, r.full_name FROM certificate_requests c LEFT JOIN residents r ON r.id = c.resident_id ORDER BY c.created_at DESC, c.id DESC')->fetchAll(PDO::FETCH_ASSOC);
$currentUserName = $currentUser['full_name'] ?? $_SESSION['admin_name'] ?? 'Administrator';
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Certificate Management | Barangay Management</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="../assets/css/dashboard.css">
<link rel="stylesheet" href="../assets/css/topbar.css">
<script src="../assets/js/topbar.js" defer></script>
<style>
.certificate-page{padding:32px 26px;min-width:0}.certificate-heading{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:24px}.certificate-heading h1{margin:0 0 6px}.certificate-heading p{margin:0;color:#64748b}.cert-table-wrap{overflow-x:auto}.cert-table{width:100%;border-collapse:collapse;text-align:left}.cert-table th,.cert-table td{padding:14px 12px;border-bottom:1px solid #e2e8f0;vertical-align:middle}.cert-table th{font-size:13px;color:#475569;background:#f8fafc}.cert-table td{font-size:14px}.cert-status{display:inline-block;padding:5px 10px;border-radius:99px;background:#e0edff;color:#1d4ed8;font-weight:600;font-size:12px}.cert-action{border:0;border-radius:8px;background:#2563eb;color:#fff;padding:9px 13px;cursor:pointer;font-weight:600}.cert-action:hover{background:#1d4ed8}.cert-alert{padding:12px 16px;margin-bottom:16px;border-radius:8px;background:#fff4e5;color:#92400e}.cert-success{background:#dcfce7;color:#166534}.cert-note{font-size:13px;color:#64748b;margin:12px 0 0}.cert-empty{padding:24px;text-align:center;color:#64748b}.cert-workflow{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:20px}.cert-workflow span{padding:9px 12px;border-radius:8px;background:#eaf1ff;color:#1e40af;font-size:13px;font-weight:600}.cert-panel{background:#fff;border-radius:12px;border:1px solid #e2e8f0;padding:18px}.cert-user{display:flex;align-items:center;gap:10px}.cert-user i{color:#2563eb}
</style></head><body>
<div class="app-layout">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main-wrapper">
<?php $pageTitle = 'Certificate Management'; include __DIR__ . '/../includes/topbar.php'; ?>
<main class="certificate-page">
<div class="certificate-heading"><div><h1>Certificate Management</h1><p>Review and process resident certificate requests.</p></div><a href="dashboard.php">Back to Dashboard</a></div>
<div class="cert-workflow"><span>1 · Requests</span><span>2 · Processing</span><span>3 · Approval</span><span>4 · Issuance</span><span>5 · Release Tracking</span></div>
<?php if ($error !== ''): ?><div class="cert-alert" role="alert"><?= e($error) ?></div><?php endif; ?>
<?php if (isset($_GET['updated'])): ?><div class="cert-alert cert-success" role="status">Request status updated.</div><?php endif; ?>
<section class="cert-panel"><div class="cert-table-wrap"><table class="cert-table"><thead><tr><th>Reference</th><th>Resident</th><th>Certificate</th><th>Purpose</th><th>Status</th><th>Next Action</th></tr></thead><tbody>
<?php foreach ($rows as $row): ?>
<tr><td><?= e($row['reference_no']) ?></td><td><?= e($row['full_name'] ?? 'Resident unavailable') ?></td><td><?= e($row['certificate_type']) ?></td><td><?= e($row['purpose']) ?></td><td><span class="cert-status"><?= e(ucwords(str_replace('_', ' ', $row['status']))) ?></span></td><td>
<?php $next = $allowed[$row['status']] ?? null; ?>
<?php if ($next !== null): ?><form method="post" action="certificates.php"><input type="hidden" name="csrf" value="<?= e($_SESSION['certificate_csrf']) ?>"><input type="hidden" name="id" value="<?= (int)$row['id'] ?>"><input type="hidden" name="status" value="<?= e($next) ?>"><button class="cert-action" type="submit"><?= $next === 'processing' ? 'Start Processing' : 'Approve for Release' ?></button></form>
<?php elseif ($row['status'] === 'for_release'): ?><span title="Issuance and release must be completed in the issuance module">Awaiting issuance</span>
<?php else: ?>—<?php endif; ?></td></tr>
<?php endforeach; ?>
<?php if (!$rows): ?><tr><td colspan="6" class="cert-empty">No certificate requests found.</td></tr><?php endif; ?>
</tbody></table></div><p class="cert-note">Release is intentionally handled separately: the issuance workflow must create the issued certificate record and update the request together. This page does not send SMS or collect payments.</p></section>
</main></div></div></body></html>
