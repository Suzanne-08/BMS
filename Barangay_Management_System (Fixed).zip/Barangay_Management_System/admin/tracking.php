<?php

require_once __DIR__ . '/../includes/auth.php';

require_once __DIR__ . '/../config/database.php';



if (!function_exists('e')) {

    function e($value): string {

        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

    }

}



$q = trim((string)($_GET['q'] ?? ''));

$q = substr($q, 0, 100);

$selectedId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;

$filter = (string)($_GET['status'] ?? 'all');

$allowedStatuses = ['all', 'pending', 'processing', 'for_release', 'released', 'rejected'];

if (!in_array($filter, $allowedStatuses, true)) $filter = 'all';



$sql = 'SELECT c.id, c.reference_no, c.certificate_type, c.purpose, c.status, c.created_at,

               r.full_name

        FROM certificate_requests c

        INNER JOIN residents r ON r.id = c.resident_id

        WHERE 1=1';

$params = [];

if ($q !== '') {

    $sql .= ' AND (c.reference_no LIKE ? OR c.certificate_type LIKE ? OR r.full_name LIKE ?)';

    $like = '%' . $q . '%';

    array_push($params, $like, $like, $like);

}

if ($filter !== 'all') {

    $sql .= ' AND c.status = ?';

    $params[] = $filter;

}

$sql .= ' ORDER BY c.created_at DESC, c.id DESC LIMIT 100';

$stmt = $pdo->prepare($sql);

$stmt->execute($params);

$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);



$counts = ['pending'=>0, 'processing'=>0, 'for_release'=>0, 'released'=>0, 'rejected'=>0];

foreach ($pdo->query('SELECT status, COUNT(*) AS total FROM certificate_requests GROUP BY status') as $row) {

    if (array_key_exists($row['status'], $counts)) $counts[$row['status']] = (int)$row['total'];

}

$total = array_sum($counts);



$selected = null;

$history = [];

if ($selectedId > 0) {

    $detail = $pdo->prepare('SELECT c.id, c.reference_no, c.certificate_type, c.purpose, c.status, c.created_at,

                                    r.full_name

                             FROM certificate_requests c

                             INNER JOIN residents r ON r.id = c.resident_id

                             WHERE c.id = ? LIMIT 1');

    $detail->execute([$selectedId]);

    $selected = $detail->fetch(PDO::FETCH_ASSOC) ?: null;

    if ($selected) {

        $hist = $pdo->prepare('SELECT h.old_status, h.new_status, h.remarks, h.changed_at,

                                      u.full_name AS changed_by_name

                               FROM request_status_history h

                               LEFT JOIN users u ON u.id = h.changed_by

                               WHERE h.request_id = ?

                               ORDER BY h.changed_at ASC, h.id ASC');

        $hist->execute([$selectedId]);

        $history = $hist->fetchAll(PDO::FETCH_ASSOC);

    }

}



function statusLabel($value): string {

    return ucwords(str_replace('_', ' ', (string)$value));

}

function displayDate($value): string {

    $time = $value ? strtotime((string)$value) : false;

    return $time ? date('M j, Y g:i A', $time) : '—';

}

?>

<!doctype html>

<html lang="en">

<head>

<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Request Tracking | Barangay Management</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<link rel="stylesheet" href="../assets/css/dashboard.css">
<link rel="stylesheet" href="../assets/css/topbar.css">

<style>

.tracking-main{padding:28px 24px;min-width:0}

.tracking-heading{display:flex;align-items:center;justify-content:space-between;gap:15px;flex-wrap:wrap;margin-bottom:22px}

.tracking-heading h1{font-size:27px;color:#0b2144;margin:0 0 5px}.tracking-heading p{color:#617595;margin:0}

.tracking-cards{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:14px;margin-bottom:22px}

.tracking-card,.tracking-panel{background:#fff;border:1px solid #dfe8f4;border-radius:12px;padding:20px}

.tracking-card small{display:block;color:#667c9a;margin-bottom:8px}.tracking-card strong{font-size:28px;color:#0c254e}

.tracking-panel{margin-bottom:20px}.tracking-panel h2{font-size:18px;margin:0 0 18px;color:#102b54}

.tracking-form{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:16px}

.tracking-form input,.tracking-form select{border:1px solid #ccd9eb;border-radius:8px;padding:11px;font:inherit;min-width:170px}

.tracking-form input{flex:1}.tracking-button{background:#087bf1;color:white;border:0;border-radius:8px;padding:11px 19px;text-decoration:none;cursor:pointer;font:inherit}

.tracking-clear{padding:11px;color:#225587;text-decoration:none}

.tracking-table-wrap{overflow-x:auto}.tracking-table{width:100%;border-collapse:collapse;min-width:700px;text-align:left}

.tracking-table th{background:#f2f6fc;color:#315078;font-size:13px}.tracking-table th,.tracking-table td{padding:13px;border-bottom:1px solid #e8edf5}

.tracking-table td{color:#213b5e}.tracking-table a{color:#087bf1;font-weight:600;text-decoration:none}

.tracking-status{display:inline-block;border-radius:999px;padding:5px 10px;background:#eef3fb;color:#345779;font-size:12px;font-weight:700}

.tracking-status.pending{background:#fff3d9;color:#946000}.tracking-status.processing{background:#e7f1ff;color:#1269c3}.tracking-status.for_release{background:#f0e9ff;color:#7140bc}.tracking-status.released{background:#e0f7ea;color:#157848}.tracking-status.rejected{background:#ffe6e6;color:#a92929}

.tracking-details{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-bottom:20px}

.tracking-details div{background:#f6f9fe;border-radius:8px;padding:12px}.tracking-details small{display:block;color:#697c99;margin-bottom:5px}.tracking-details strong{color:#193354}

.tracking-timeline{list-style:none;margin:0;padding:0 0 0 22px;border-left:2px solid #cfe0f7}

.tracking-timeline li{position:relative;padding:0 0 22px 18px}.tracking-timeline li:before{content:"";position:absolute;left:-29px;top:4px;width:12px;height:12px;border-radius:50%;background:#087bf1;border:3px solid white;box-shadow:0 0 0 1px #b6d0f5}

.tracking-timeline p{margin:6px 0;color:#536985}.tracking-muted{color:#6c809d}

@media(max-width:1050px){.tracking-cards{grid-template-columns:repeat(3,minmax(0,1fr))}}

@media(max-width:650px){.tracking-cards{grid-template-columns:repeat(2,minmax(0,1fr))}.tracking-details{grid-template-columns:1fr}.tracking-main{padding:18px 12px}}

</style>

</head>

<body>

<div class="app-layout">

<?php include __DIR__ . '/../includes/sidebar.php'; ?>

<div class="main-wrapper">

<?php
$pageTitle = 'Request Tracking';
include __DIR__ . '/../includes/topbar.php';
?>

<main class="dashboard-content tracking-main">

<div class="tracking-heading"><div><h1>Request Tracking</h1><p>Monitor certificate requests and review their recorded status history.</p></div><span class="tracking-muted"><i class="fa-solid fa-location-dot"></i> Barangay Management</span></div>

<section class="tracking-cards">

<div class="tracking-card"><small>Total Requests</small><strong><?= number_format($total) ?></strong></div>

<?php foreach (['pending'=>'Pending','processing'=>'Processing','for_release'=>'For Release','released'=>'Released'] as $key=>$label): ?>

<div class="tracking-card"><small><?= e($label) ?></small><strong><?= number_format($counts[$key]) ?></strong></div>

<?php endforeach; ?>

</section>

<section class="tracking-panel">

<h2><i class="fa-solid fa-magnifying-glass"></i> Find a Request</h2>

<form method="get" action="tracking.php" class="tracking-form">

<input type="search" name="q" value="<?= e($q) ?>" placeholder="Reference number, resident or certificate type" aria-label="Search requests">

<select name="status" aria-label="Filter status"><option value="all">All Statuses</option>

<?php foreach ($counts as $key=>$count): ?><option value="<?= e($key) ?>" <?= $filter===$key?'selected':'' ?>><?= e(statusLabel($key)) ?></option><?php endforeach; ?>

</select><button type="submit" class="tracking-button">Search</button><a href="tracking.php" class="tracking-clear">Clear</a>

</form>

<div class="tracking-table-wrap"><table class="tracking-table"><thead><tr><th>Reference</th><th>Resident</th><th>Certificate</th><th>Submitted</th><th>Status</th><th>Action</th></tr></thead><tbody>

<?php if (!$requests): ?><tr><td colspan="6" class="tracking-muted">No matching requests found.</td></tr><?php endif; ?>

<?php foreach ($requests as $r): ?><tr><td><?= e($r['reference_no']) ?></td><td><?= e($r['full_name']) ?></td><td><?= e($r['certificate_type']) ?></td><td><?= e(displayDate($r['created_at'])) ?></td><td><span class="tracking-status <?= e($r['status']) ?>"><?= e(statusLabel($r['status'])) ?></span></td><td><a href="?id=<?= (int)$r['id'] ?>&amp;q=<?= urlencode($q) ?>&amp;status=<?= urlencode($filter) ?>">View Timeline</a></td></tr><?php endforeach; ?>

</tbody></table></div>

</section>

<?php if ($selected): ?>

<section class="tracking-panel" id="timeline"><h2>Tracking History — <?= e($selected['reference_no']) ?></h2>

<div class="tracking-details"><div><small>Resident</small><strong><?= e($selected['full_name']) ?></strong></div><div><small>Certificate</small><strong><?= e($selected['certificate_type']) ?></strong></div><div><small>Current Status</small><strong><?= e(statusLabel($selected['status'])) ?></strong></div><div><small>Submitted</small><strong><?= e(displayDate($selected['created_at'])) ?></strong></div></div>

<ol class="tracking-timeline"><li><strong>Request submitted</strong><p><?= e(displayDate($selected['created_at'])) ?></p></li>

<?php foreach ($history as $h): ?><li><strong><?= e(statusLabel($h['new_status'])) ?></strong><p><?= e(displayDate($h['changed_at'])) ?> · <?= e($h['changed_by_name'] ?: 'System') ?></p><?php if (!empty($h['remarks'])): ?><p><?= e($h['remarks']) ?></p><?php endif; ?><?php if ($h['old_status'] !== null): ?><small class="tracking-muted">From <?= e(statusLabel($h['old_status'])) ?></small><?php endif; ?></li><?php endforeach; ?>

</ol>

<?php if (!$history && $selected['status'] !== 'pending'): ?><p class="tracking-muted">No status-change history has been recorded for this request. Its current status is <?= e(statusLabel($selected['status'])) ?>.</p><?php endif; ?>

</section>

<?php elseif ($selectedId): ?><section class="tracking-panel">Request not found.</section><?php endif; ?>

</main></div></div>

<script src="../assets/js/topbar.js" defer></script>

</body></html>
