<?php

declare(strict_types=1);



require_once __DIR__ . '/../includes/auth.php';

require_once __DIR__ . '/../config/database.php';



if (!function_exists('e')) {

    function e($value): string {

        return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

    }

}

if (empty($_SESSION['residents_csrf'])) {

    $_SESSION['residents_csrf'] = bin2hex(random_bytes(32));

}

$csrf = $_SESSION['residents_csrf'];

$adminName = $currentUser['full_name'] ?? $_SESSION['admin_name'] ?? 'Administrator';

$fields = ['resident_no','full_name','dob','sex','civil_status','address','contact_no','household_no','household_info','occupation'];

$tags = ['senior_citizen'=>'Senior Citizen','pwd'=>'PWD','solo_parent'=>'Solo Parent','four_ps'=>'4Ps','farmer'=>'Farmer'];

$errors = [];

$edit = null;

$view = null;

$form = [];



if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) {

        http_response_code(403);

        exit('Invalid security token. Refresh the page and try again.');

    }

    $action = (string)($_POST['action'] ?? '');

    $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]) ?: 0;

    if ($action === 'delete') {

        if (!$id) {

            $errors[] = 'Invalid resident selected.';

        } else {

            try {

                $stmt = $pdo->prepare('DELETE FROM residents WHERE id = ?');

                $stmt->execute([$id]);

                $_SESSION['residents_flash'] = $stmt->rowCount() ? 'Resident deleted successfully.' : 'Resident not found.';

                header('Location: residents.php');

                exit;

            } catch (PDOException $ex) {

                $errors[] = 'Cannot delete this resident. The record may be linked to certificates or transactions.';

            }

        }

    } elseif ($action === 'save') {

        foreach ($fields as $field) {

            $form[$field] = trim((string)($_POST[$field] ?? ''));

        }

        foreach ($tags as $key => $label) {

            $form[$key] = isset($_POST[$key]) ? 1 : 0;

        }

        $form['id'] = $id;

        if ($form['resident_no'] === '' || $form['full_name'] === '') {

            $errors[] = 'Resident ID and full name are required.';

        }

        if ($form['dob'] !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $form['dob'])) {

            $errors[] = 'Enter a valid date of birth.';

        }

        if (!in_array($form['sex'], ['Male','Female','Other'], true)) {

            $errors[] = 'Select a valid sex.';

        }

        if (!in_array($form['civil_status'], ['Single','Married','Widow','Widowed','Separated','Divorced'], true)) {

            $errors[] = 'Select a valid civil status.';

        }

        if (!$errors) {

            $cols = array_merge($fields, array_keys($tags));

            $values = [];

            foreach ($cols as $col) {

                $values[] = $col === 'dob' && $form[$col] === '' ? null : $form[$col];

            }

            try {

                if ($id) {

                    $assignments = implode(', ', array_map(fn($c) => "`$c` = ?", $cols));

                    $stmt = $pdo->prepare("UPDATE residents SET $assignments WHERE id = ?");

                    $stmt->execute([...$values, $id]);

                    $message = 'Resident updated successfully.';

                } else {

                    $names = implode(', ', array_map(fn($c) => "`$c`", $cols));

                    $marks = implode(', ', array_fill(0, count($cols), '?'));

                    $stmt = $pdo->prepare("INSERT INTO residents ($names) VALUES ($marks)");

                    $stmt->execute($values);

                    $message = 'Resident added successfully.';

                }

                $_SESSION['residents_flash'] = $message;

                header('Location: residents.php');

                exit;

            } catch (PDOException $ex) {

                error_log('Resident save error: ' . $ex->getMessage());

                $errors[] = 'Could not save the resident. Check for duplicate Resident ID or incompatible database values.';

            }

        }

    } else {

        $errors[] = 'Unknown action.';

    }

}



$flash = $_SESSION['residents_flash'] ?? null;

unset($_SESSION['residents_flash']);

$editId = filter_var($_GET['edit'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]) ?: 0;

$viewId = filter_var($_GET['view'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]) ?: 0;

if ($editId || $viewId) {

    $stmt = $pdo->prepare('SELECT * FROM residents WHERE id = ?');

    $stmt->execute([$editId ?: $viewId]);

    $record = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($editId) $edit = $record ?: null;

    if ($viewId) $view = $record ?: null;

    if (!$record) $errors[] = 'Resident record not found.';

}

$showForm = (($_GET['action'] ?? '') === 'add') || $edit !== null || ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save' && $errors);

if (!$form && $edit) $form = $edit;

$q = trim((string)($_GET['q'] ?? ''));

$q = substr($q, 0, 100);

$like = '%' . $q . '%';

$stmt = $pdo->prepare('SELECT * FROM residents WHERE resident_no LIKE ? OR full_name LIKE ? OR address LIKE ? ORDER BY full_name ASC');

$stmt->execute([$like, $like, $like]);

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalResidents = (int)$pdo->query('SELECT COUNT(*) FROM residents')->fetchColumn();

?>

<!doctype html>

<html lang="en">

<head>

<meta charset="utf-8">

<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Resident Management | Barangay Management</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<link rel="stylesheet" href="../assets/css/dashboard.css">
<link rel="stylesheet" href="../assets/css/topbar.css">

<style>

/* Page-specific styling; dashboard.css controls the shared sidebar. */

.resident-content{padding:26px 26px 45px;min-width:0}

.resident-heading{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:22px;flex-wrap:wrap}

.resident-heading h1{margin:0 0 6px;color:#0a2147;font-size:27px}

.resident-heading p{margin:0;color:#5e7393}

.resident-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:11px 17px;border-radius:9px;background:#087af1;color:white!important;border:0;font-weight:650;text-decoration:none;cursor:pointer;font-size:14px}

.resident-btn:hover{background:#0068d3}

.resident-btn.secondary{background:#eaf1fb;color:#25446c!important}

.resident-btn.danger{background:#d92e42}

.resident-panel{background:#fff;border:1px solid #dfe8f4;border-radius:13px;padding:22px;margin-bottom:20px;min-width:0}

.resident-panel h2{margin:0;color:#0a2147;font-size:18px}

.resident-panel-head{display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;margin-bottom:18px}

.resident-search{display:flex;gap:8px;flex-wrap:wrap}

.resident-search input,.resident-form input,.resident-form select{border:1px solid #cedbed;border-radius:8px;padding:10px 12px;font:inherit;background:white;color:#142a4d;min-width:0;width:100%;box-sizing:border-box}

.resident-search input{width:min(310px,65vw)}

.resident-table-wrap{overflow-x:auto;width:100%}

.resident-table{border-collapse:collapse;width:100%;min-width:840px;text-align:left;font-size:14px}

.resident-table th{background:#f0f5fc;color:#375477;font-weight:650;padding:13px 12px}

.resident-table td{padding:14px 12px;border-bottom:1px solid #e6edf6;color:#233f64;vertical-align:middle}

.resident-table td strong{color:#0a2147;display:block}

.resident-table td small{color:#7084a0;display:block;margin-top:3px}

.resident-table tr:last-child td{border-bottom:0}

.resident-actions{display:flex;align-items:center;gap:9px;white-space:nowrap}

.resident-actions a{color:#0672e4;text-decoration:none;font-weight:600}

.resident-actions form{margin:0}

.resident-actions button{border:0;background:transparent;color:#d12b40;cursor:pointer;font:inherit;font-weight:600;padding:0}

.resident-form-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin-top:18px}

.resident-form label{display:flex;flex-direction:column;gap:7px;color:#304b70;font-weight:600;font-size:13px}

.resident-tags{border:1px solid #dfe8f4;border-radius:9px;padding:15px;margin-top:20px;display:flex;flex-wrap:wrap;gap:16px}

.resident-tags legend{font-weight:650;color:#304b70;padding:0 6px}

.resident-tags label{flex-direction:row;align-items:center;gap:7px}

.resident-tags input{width:auto}

.resident-form-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:20px}

.resident-notice{padding:12px 15px;border-radius:9px;background:#e7f7ef;color:#17603d;margin-bottom:18px}

.resident-notice.error{background:#fff0f1;color:#a32036}

.resident-count{background:#edf5ff;border-radius:9px;padding:10px 14px;color:#2863a3;font-weight:600}

.resident-profile-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:18px 0}

.resident-profile-grid div{background:#f5f8fd;border-radius:8px;padding:12px}

.resident-profile-grid small{display:block;color:#7185a0;margin-bottom:5px}

.resident-profile-grid strong{color:#142a4d;overflow-wrap:anywhere}

@media(max-width:950px){.resident-form-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}

@media(max-width:600px){.resident-content{padding:18px 12px}.resident-form-grid,.resident-profile-grid{grid-template-columns:1fr}.resident-panel{padding:14px}}

</style>

</head>

<body>

<div class="app-layout">

<?php include __DIR__ . '/../includes/sidebar.php'; ?>

<div class="main-wrapper">

<?php
$pageTitle = 'Resident Management';
include __DIR__ . '/../includes/topbar.php';
?>

<main class="dashboard-content resident-content">

<div class="resident-heading"><div><h1>Resident Management</h1><p>Manage, search, and update barangay resident records.</p></div><div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap"><span class="resident-count"><?= number_format($totalResidents) ?> Residents</span><a class="resident-btn" href="residents.php?action=add"><i class="fa-solid fa-user-plus"></i> Add Resident Record</a></div></div>

<?php if ($flash): ?><div class="resident-notice" role="status"><?= e($flash) ?></div><?php endif; ?>

<?php foreach ($errors as $error): ?><div class="resident-notice error" role="alert"><?= e($error) ?></div><?php endforeach; ?>

<?php if ($view): ?>

<section class="resident-panel"><div class="resident-panel-head"><h2>Resident Profile</h2><a class="resident-btn secondary" href="residents.php">Close</a></div><div class="resident-profile-grid">

<?php foreach (['resident_no'=>'Resident ID','full_name'=>'Full Name','dob'=>'Date of Birth','sex'=>'Sex','civil_status'=>'Civil Status','address'=>'Address','contact_no'=>'Contact Number','household_no'=>'Household Number','household_info'=>'Household Information','occupation'=>'Occupation'] as $key=>$label): ?>

<div><small><?= e($label) ?></small><strong><?= e($view[$key] ?? '—') ?></strong></div>

<?php endforeach; ?>

<div><small>Classification</small><strong><?php $vTags=[];foreach($tags as $key=>$label){if(!empty($view[$key]))$vTags[]=$label;}echo e(implode(', ', $vTags) ?: 'None'); ?></strong></div>

</div><a class="resident-btn" href="residents.php?edit=<?= (int)$view['id'] ?>">Edit Resident</a></section>

<?php endif; ?>

<?php if ($showForm): ?>

<section class="resident-panel"><div class="resident-panel-head"><h2><?= !empty($form['id']) ? 'Edit Resident Record' : 'Add Resident Record' ?></h2><a href="residents.php" class="resident-btn secondary">Cancel</a></div>

<form method="post" class="resident-form">

<input type="hidden" name="csrf" value="<?= e($csrf) ?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)($form['id'] ?? 0) ?>">

<div class="resident-form-grid">

<?php foreach (['resident_no'=>'Resident ID','full_name'=>'Full Name','dob'=>'Date of Birth','address'=>'Address','contact_no'=>'Contact Number','household_no'=>'Household Number','household_info'=>'Household Information','occupation'=>'Occupation'] as $key=>$label): ?>

<label><?= e($label) ?><input type="<?= $key === 'dob' ? 'date' : 'text' ?>" name="<?= e($key) ?>" value="<?= e($form[$key] ?? '') ?>" <?= in_array($key,['resident_no','full_name'],true) ? 'required' : '' ?>></label>

<?php endforeach; ?>

<label>Sex<select name="sex"><?php foreach(['Male','Female','Other'] as $option): ?><option value="<?= e($option) ?>" <?= ($form['sex'] ?? 'Male') === $option ? 'selected' : '' ?>><?= e($option) ?></option><?php endforeach; ?></select></label>

<label>Civil Status<select name="civil_status"><?php foreach(['Single','Married','Widow','Widowed','Separated','Divorced'] as $option): ?><option value="<?= e($option) ?>" <?= ($form['civil_status'] ?? 'Single') === $option ? 'selected' : '' ?>><?= e($option) ?></option><?php endforeach; ?></select></label>

</div><fieldset class="resident-tags"><legend>Classification / Sector</legend>

<?php foreach ($tags as $key=>$label): ?><label><input type="checkbox" name="<?= e($key) ?>" value="1" <?= !empty($form[$key]) ? 'checked' : '' ?>><?= e($label) ?></label><?php endforeach; ?>

</fieldset><div class="resident-form-actions"><a href="residents.php" class="resident-btn secondary">Cancel</a><button class="resident-btn" type="submit"><i class="fa-solid fa-floppy-disk"></i> Save Resident</button></div></form></section>

<?php endif; ?>

<section class="resident-panel"><div class="resident-panel-head"><h2>Resident Records</h2><form class="resident-search" method="get" action="residents.php"><input name="q" type="search" placeholder="Search ID, name or address" value="<?= e($q) ?>"><button type="submit" class="resident-btn"><i class="fa-solid fa-magnifying-glass"></i> Search</button></form></div>

<div class="resident-table-wrap"><table class="resident-table"><thead><tr><th>Resident ID</th><th>Full Name</th><th>Sex</th><th>Contact</th><th>Household</th><th>Classification</th><th>Actions</th></tr></thead><tbody>

<?php if (!$rows): ?><tr><td colspan="7">No matching residents found.</td></tr><?php endif; ?>

<?php foreach ($rows as $r): $rTags=[];foreach($tags as $key=>$label){if(!empty($r[$key]))$rTags[]=$label;} ?>

<tr><td><?= e($r['resident_no']) ?></td><td><strong><?= e($r['full_name']) ?></strong><small><?= e($r['address']) ?></small></td><td><?= e($r['sex']) ?></td><td><?= e($r['contact_no']) ?></td><td><?= e($r['household_no']) ?></td><td><?= e(implode(', ', $rTags) ?: '—') ?></td><td><div class="resident-actions"><a href="residents.php?view=<?= (int)$r['id'] ?>">View</a><a href="residents.php?edit=<?= (int)$r['id'] ?>">Edit</a><form method="post" onsubmit="return confirm('Delete this resident? This action cannot be undone.');"><input type="hidden" name="csrf" value="<?= e($csrf) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button type="submit">Delete</button></form></div></td></tr>

<?php endforeach; ?>

</tbody></table></div></section>

</main></div></div>

<script src="../assets/js/topbar.js" defer></script>

</body></html>
