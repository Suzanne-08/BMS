<?php

require_once __DIR__ . '/../includes/auth.php';

require_once __DIR__ . '/../config/database.php';

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

if (empty($_SESSION['sms_csrf'])) $_SESSION['sms_csrf'] = bin2hex(random_bytes(32));

function smsEscape($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

$notice = $_SESSION['sms_notice'] ?? ''; unset($_SESSION['sms_notice']);

$error = '';

$types = [];

try {

    $stmt = $pdo->query("SHOW COLUMNS FROM sms_notifications LIKE 'notification_type'");

    $typeDef = (string)($stmt->fetch(PDO::FETCH_ASSOC)['Type'] ?? '');

    if (preg_match('/^enum\((.*)\)$/i', $typeDef, $m)) {

        $types = str_getcsv($m[1], ',', "'", '\\');



    }

} catch (Throwable $e) { error_log($e->getMessage()); }

if (!$types) $error = 'Could not determine the allowed notification types. Check the sms_notifications table schema.';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $token = (string)($_POST['csrf'] ?? '');

    if (!hash_equals($_SESSION['sms_csrf'], $token)) {

        $error = 'Security token expired. Refresh the page and try again.';

    } elseif (!$types) {

        $error = 'SMS notification types are unavailable.';

    } else {

        $residentId = filter_var($_POST['resident_id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);

        $requestId = filter_var($_POST['request_id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);

        $recipient = trim((string)($_POST['recipient_name'] ?? ''));

        $contact = trim((string)($_POST['contact_no'] ?? ''));

        $type = (string)($_POST['notification_type'] ?? '');

        $message = trim((string)($_POST['message'] ?? ''));

        if ($recipient === '' || mb_strlen($recipient) > 120 || !preg_match('/^\+?[0-9]{10,15}$/', $contact) || !in_array($type, $types, true) || $message === '' || mb_strlen($message) > 255) {

            $error = 'Enter a recipient (max 120 characters), valid mobile number, allowed notification type, and message (max 255 characters).';

        } else {

            try {

                if ($residentId) {

                    $s = $pdo->prepare('SELECT COUNT(*) FROM residents WHERE id = ?'); $s->execute([$residentId]);

                    if (!(int)$s->fetchColumn()) throw new RuntimeException('Resident ID does not exist.');

                }

                if ($requestId) {

                    $s = $pdo->prepare('SELECT COUNT(*) FROM certificate_requests WHERE id = ?'); $s->execute([$requestId]);

                    if (!(int)$s->fetchColumn()) throw new RuntimeException('Request ID does not exist.');

                }

                $s = $pdo->prepare("INSERT INTO sms_notifications (resident_id, request_id, recipient_name, contact_no, notification_type, message, status) VALUES (?, ?, ?, ?, ?, ?, 'queued')");

                $s->execute([$residentId ?: null, $requestId ?: null, $recipient, $contact, $type, $message]);

                $_SESSION['sms_notice'] = 'Notification queued in development mode. No actual SMS was sent.';

                header('Location: sms_notifications.php'); exit;

            } catch (Throwable $e) { error_log($e->getMessage()); $error = $e instanceof RuntimeException ? $e->getMessage() : 'Could not save notification. Check your database constraints.'; }

        }

    }

}

$search = trim((string)($_GET['q'] ?? ''));

$status = (string)($_GET['status'] ?? 'all');

if (!in_array($status, ['all', 'queued', 'sent', 'failed'], true)) $status = 'all';

$where = []; $params = [];

if ($search !== '') { $where[] = '(recipient_name LIKE ? OR contact_no LIKE ? OR message LIKE ?)'; $term = '%' . mb_substr($search, 0, 80) . '%'; $params = [$term, $term, $term]; }

if ($status !== 'all') { $where[] = 'status = ?'; $params[] = $status; }

$sql = 'SELECT id, recipient_name, contact_no, notification_type, message, status, created_at FROM sms_notifications' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY created_at DESC, id DESC LIMIT 100';

$s = $pdo->prepare($sql); $s->execute($params); $records = $s->fetchAll(PDO::FETCH_ASSOC);

$stats = ['queued'=>0,'sent'=>0,'failed'=>0];

foreach ($pdo->query('SELECT status, COUNT(*) total FROM sms_notifications GROUP BY status') as $r) if (isset($stats[$r['status']])) $stats[$r['status']] = (int)$r['total'];

$adminName = $currentUser['full_name'] ?? $_SESSION['admin_name'] ?? 'Administrator';

?>

<!doctype html>

<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SMS Notifications | Barangay Management</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<link rel="stylesheet" href="../assets/css/dashboard.css">
<link rel="stylesheet" href="../assets/css/topbar.css">

<style>

.sms-page{padding:24px;max-width:1500px;margin:auto}.sms-heading{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:20px}.sms-heading h1{margin:0 0 6px}.sms-muted{color:#64748b}.sms-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin-bottom:20px}.sms-card,.sms-panel{background:white;border:1px solid #dfe6f2;border-radius:12px;padding:20px}.sms-card strong{display:block;font-size:30px;color:#0b2553}.sms-card span{color:#64748b}.sms-grid{display:grid;grid-template-columns:minmax(280px,1fr) minmax(0,1.7fr);gap:18px}.sms-form{display:grid;gap:12px}.sms-form label{display:grid;gap:5px;font-weight:600}.sms-form input,.sms-form select,.sms-form textarea,.sms-filter input,.sms-filter select{padding:10px;border:1px solid #cbd5e1;border-radius:7px;font:inherit;width:100%;box-sizing:border-box}.sms-form textarea{min-height:110px;resize:vertical}.sms-btn{border:0;border-radius:8px;background:#1379ee;color:white;padding:11px 15px;cursor:pointer;font-weight:600}.sms-filter{display:flex;gap:8px;margin-bottom:15px}.sms-table-wrap{overflow-x:auto}.sms-table{width:100%;border-collapse:collapse;text-align:left;font-size:13px}.sms-table th,.sms-table td{padding:12px;border-bottom:1px solid #e5eaf2;vertical-align:top}.sms-table th{background:#f2f6fc}.sms-status{font-weight:700;text-transform:capitalize}.sms-alert{padding:12px;border-radius:8px;margin-bottom:14px;background:#e8f4ff;color:#124b82}.sms-error{background:#fff0f0;color:#a12626}.sms-note{font-size:13px;color:#64748b}.sms-panel h2{margin:0 0 16px;font-size:19px}@media(max-width:1050px){.sms-grid{grid-template-columns:1fr}}@media(max-width:650px){.sms-cards{grid-template-columns:1fr}.sms-page{padding:14px}.sms-filter{flex-wrap:wrap}}

</style></head>

<body><div class="app-layout"><?php include __DIR__ . '/../includes/sidebar.php'; ?><div class="main-wrapper">

<?php $pageTitle = 'SMS Notifications'; include __DIR__ . '/../includes/topbar.php'; ?>

<main class="dashboard-content"><div class="sms-page"><div class="sms-heading"><div><h1>SMS Notifications</h1><p class="sms-muted">Compose, queue, and review resident notifications.</p></div><span class="sms-muted"><i class="fa-solid fa-flask"></i> Development mode — no SMS provider connected</span></div>

<?php if ($notice): ?><div class="sms-alert" role="status"><?= smsEscape($notice) ?></div><?php endif; ?>

<?php if ($error): ?><div class="sms-alert sms-error" role="alert"><?= smsEscape($error) ?></div><?php endif; ?>

<div class="sms-cards"><div class="sms-card"><strong><?= $stats['queued'] ?></strong><span>Queued</span></div><div class="sms-card"><strong><?= $stats['sent'] ?></strong><span>Sent (historical records)</span></div><div class="sms-card"><strong><?= $stats['failed'] ?></strong><span>Failed</span></div></div>

<div class="sms-grid"><section class="sms-panel"><h2><i class="fa-regular fa-paper-plane"></i> Queue Notification</h2><form class="sms-form" method="post"><input type="hidden" name="csrf" value="<?= smsEscape($_SESSION['sms_csrf']) ?>">

<label>Recipient name <input name="recipient_name" maxlength="120" required value="<?= smsEscape($_POST['recipient_name'] ?? '') ?>"></label>

<label>Contact number <input name="contact_no" placeholder="09XXXXXXXXX" maxlength="16" required value="<?= smsEscape($_POST['contact_no'] ?? '') ?>"></label>

<label>Resident ID (optional) <input name="resident_id" type="number" min="1" value="<?= smsEscape($_POST['resident_id'] ?? '') ?>"></label>

<label>Request ID (optional) <input name="request_id" type="number" min="1" value="<?= smsEscape($_POST['request_id'] ?? '') ?>"></label>

<label>Notification type <select name="notification_type" required><?php foreach ($types as $t): ?><option value="<?= smsEscape($t) ?>" <?= ($_POST['notification_type'] ?? '') === $t ? 'selected' : '' ?>><?= smsEscape(ucwords(str_replace('_',' ',$t))) ?></option><?php endforeach; ?></select></label>

<label>Message <textarea name="message" maxlength="255" required><?= smsEscape($_POST['message'] ?? '') ?></textarea></label>

<p class="sms-note">Submitting saves a queued database record only. It does not contact the recipient.</p><button class="sms-btn" type="submit" <?= !$types ? 'disabled' : '' ?>>Queue SMS Notification</button></form></section>

<section class="sms-panel"><h2><i class="fa-solid fa-clock-rotate-left"></i> Notification History</h2><form method="get" class="sms-filter"><input name="q" placeholder="Search recipient, phone, message" value="<?= smsEscape($search) ?>"><select name="status"><?php foreach (['all'=>'All statuses','queued'=>'Queued','sent'=>'Sent','failed'=>'Failed'] as $v=>$label): ?><option value="<?= $v ?>" <?= $status===$v?'selected':'' ?>><?= $label ?></option><?php endforeach; ?></select><button class="sms-btn">Search</button></form>

<div class="sms-table-wrap"><table class="sms-table"><thead><tr><th>Recipient</th><th>Type</th><th>Message</th><th>Status</th><th>Date</th></tr></thead><tbody><?php if (!$records): ?><tr><td colspan="5">No notifications found.</td></tr><?php endif; ?><?php foreach ($records as $r): ?><tr><td><strong><?= smsEscape($r['recipient_name']) ?></strong><div class="sms-muted"><?= smsEscape($r['contact_no']) ?></div></td><td><?= smsEscape(ucwords(str_replace('_',' ',$r['notification_type']))) ?></td><td><?= smsEscape($r['message']) ?></td><td><span class="sms-status"><?= smsEscape($r['status']) ?></span></td><td><?= smsEscape($r['created_at']) ?></td></tr><?php endforeach; ?></tbody></table></div><p class="sms-note">Showing up to 100 most recent matching records.</p></section></div></div></main></div></div><script src="../assets/js/topbar.js" defer></script>
</body></html>
