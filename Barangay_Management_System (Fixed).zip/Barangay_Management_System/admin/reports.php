<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';

function reportEscape($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$start = trim((string)($_GET['from'] ?? ''));
$end = trim((string)($_GET['to'] ?? ''));
$validDate = static function (string $date): bool {
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
    return $d !== false && $d->format('Y-m-d') === $date;
};
$error = '';
if (($start !== '' && !$validDate($start)) || ($end !== '' && !$validDate($end)) || ($start !== '' && $end !== '' && $start > $end)) {
    $error = 'Please enter a valid date range.';
    $start = $end = '';
}

function reportCount(PDO $pdo, string $table, string $dateColumn, string $from, string $to): int {
    $allowed = ['residents' => null, 'certificate_requests' => 'created_at', 'payments' => 'paid_at', 'sms_notifications' => 'created_at', 'issued_certificates' => 'issued_at'];
    if (!array_key_exists($table, $allowed)) { throw new InvalidArgumentException('Unknown table'); }
    // Residents has no confirmed creation timestamp; count all registered residents.
    if ($allowed[$table] === null) {
        return (int)$pdo->query('SELECT COUNT(*) FROM residents')->fetchColumn();
    }
    $column = $allowed[$table];
    $where = []; $params = [];
    if ($from !== '') { $where[] = "$column >= ?"; $params[] = $from . ' 00:00:00'; }
    if ($to !== '') { $where[] = "$column < ?"; $params[] = (new DateTimeImmutable($to))->modify('+1 day')->format('Y-m-d 00:00:00'); }
    $sql = "SELECT COUNT(*) FROM $table" . ($where ? ' WHERE ' . implode(' AND ', $where) : '');
    $stmt = $pdo->prepare($sql); $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

$r = reportCount($pdo, 'residents', '', $start, $end);
$c = reportCount($pdo, 'certificate_requests', '', $start, $end);
$t = reportCount($pdo, 'payments', '', $start, $end);
$s = reportCount($pdo, 'sms_notifications', '', $start, $end);
$i = reportCount($pdo, 'issued_certificates', '', $start, $end);

$paymentWhere = ["status = 'paid'"];
$paymentParams = [];
if ($start !== '') { $paymentWhere[] = 'paid_at >= ?'; $paymentParams[] = $start . ' 00:00:00'; }
if ($end !== '') { $paymentWhere[] = 'paid_at < ?'; $paymentParams[] = (new DateTimeImmutable($end))->modify('+1 day')->format('Y-m-d 00:00:00'); }
$st = $pdo->prepare('SELECT COALESCE(SUM(amount), 0) FROM payments WHERE ' . implode(' AND ', $paymentWhere));
$st->execute($paymentParams);
$revenue = (float)$st->fetchColumn();

$metrics = [
    ['Resident Reports', $r, 'Total registered residents (all dates)', 'residents.php', 'View Residents', 'fa-users', 'blue'],
    ['Certificate Reports', $c, 'Certificate requests in selected period', 'certificates.php', 'View Certificates', 'fa-file-lines', 'orange'],
    ['Transaction Reports', $t, 'Payment records in selected period', 'payments.php', 'View Payments', 'fa-credit-card', 'purple'],
    ['SMS Notification Records', $s, 'Notification records in selected period', 'sms_notifications.php', 'View SMS Records', 'fa-comment-sms', 'green'],
    ['Certificates Issued', $i, 'Issuance records in selected period', 'issued_certificates.php', 'View Issuance', 'fa-certificate', 'blue'],
    ['Payments Received', '₱' . number_format($revenue, 2), 'Sum of paid transactions in selected period', 'payments.php', 'View Payments', 'fa-peso-sign', 'green'],
];

if (($_GET['export'] ?? '') === 'csv' && !$error) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="barangay_reports_' . date('Ymd_His') . '.csv"');
    header('Cache-Control: no-store');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Report', 'Value', 'Period From', 'Period To']);
    foreach ($metrics as $metric) { fputcsv($out, [$metric[0], $metric[1], $start ?: 'All', $end ?: 'All']); }
    fclose($out);
    exit;
}
$adminName = $currentUser['full_name'] ?? $_SESSION['admin_name'] ?? 'Administrator';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reports &amp; Records | Barangay Management</title>
<link rel="stylesheet" href="../assets/css/dashboard.css">
<link rel="stylesheet" href="../assets/css/topbar.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
.report-filter{display:flex;flex-wrap:wrap;align-items:end;gap:12px;margin-bottom:20px}
.report-filter label{display:flex;flex-direction:column;gap:6px;font-size:12px;font-weight:600;color:#395780}
.report-filter input{padding:10px 12px;border:1px solid #dbe5f2;border-radius:8px;background:white;color:#091b42}
.report-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:11px 15px;border-radius:8px;border:0;background:#0879f9;color:white;font-size:12px;font-weight:700;cursor:pointer}
.report-btn.secondary{background:#eef4fc;color:#174269}
.report-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.report-card{display:flex;flex-direction:column;align-items:flex-start;gap:12px}
.report-card h2{font-size:17px}
.report-card .value{font-size:30px;font-weight:800;color:#0879f9}
.report-card p{font-size:13px;color:#60749a;line-height:1.5;flex:1}
.report-notice{margin-bottom:16px;color:#9b381b;font-size:13px}
@media(max-width:750px){.report-grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="app-layout">
<?php require __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main-wrapper">
<?php $pageTitle = 'Reports & Records'; include __DIR__ . '/../includes/topbar.php'; ?>
<main class="dashboard-content">
<div class="page-heading"><div><h1>Reports &amp; Records</h1><p>Overview of barangay residents, certificates, payments, and notifications.</p></div></div>
<?php if ($error): ?><p class="report-notice" role="alert"><?= reportEscape($error) ?></p><?php endif; ?>
<section class="panel" style="margin-bottom:18px">
 <div class="panel-heading"><h2>Report Filters</h2></div>
 <form class="report-filter" method="get">
  <label>From <input type="date" name="from" value="<?= reportEscape($start) ?>"></label>
  <label>To <input type="date" name="to" value="<?= reportEscape($end) ?>"></label>
  <button class="report-btn" type="submit"><i class="fa-solid fa-filter"></i> Apply Filters</button>
  <a class="report-btn secondary" href="reports.php">Clear</a>
  <a class="report-btn" href="?<?= reportEscape(http_build_query(['from'=>$start,'to'=>$end,'export'=>'csv'])) ?>"><i class="fa-solid fa-file-csv"></i> Export CSV</a>
 </form>
 <p style="font-size:12px;color:#60749a">Resident count always includes all registered residents because the residents table's creation-date column has not been confirmed. Payment totals use confirmed paid records only.</p>
</section>
<div class="report-grid">
<?php foreach ($metrics as $metric): ?>
<section class="panel report-card">
  <div class="stat-icon <?= reportEscape($metric[6]) ?>" aria-hidden="true"><i class="fa-solid <?= reportEscape($metric[5]) ?>"></i></div>
  <h2><?= reportEscape($metric[0]) ?></h2>
  <div class="value"><?= reportEscape($metric[1]) ?></div>
  <p><?= reportEscape($metric[2]) ?></p>
  <a class="report-btn" href="<?= reportEscape($metric[3]) ?>"><?= reportEscape($metric[4]) ?> <i class="fa-solid fa-arrow-right"></i></a>
</section>
<?php endforeach; ?>
</div>
</main>
</div>
</div>
<script src="../assets/js/topbar.js" defer></script>
</body>
</html>
