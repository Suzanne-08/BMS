<?php
require '../includes/auth.php';
require '../config/database.php';

$rows = $pdo->query(
	'SELECT * FROM sms_notifications ORDER BY created_at DESC LIMIT 50'
)->fetchAll();
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="../assets/css/style.css">
	<title>SMS Notifications</title>
</head>
<body>
	<div class="app">
		<?php include '../includes/sidebar.php'; ?>

		<main class="content">
			<header class="top">
				<b>SMS Notification Panel</b>
			</header>

			<section class="page">
				<h1>SMS Notifications</h1>
				<div class="counter-grid">
					<article class="counter">
						<span>✓</span>
						<div>
							<strong>Request Confirmation</strong>
							<small>Alerts when requests are submitted</small>
						</div>
					</article>
					<article class="counter">
						<span>⟳</span>
						<div>
							<strong>Processing Updates</strong>
							<small>Status change notifications</small>
						</div>
					</article>
					<article class="counter">
						<span>📦</span>
						<div>
							<strong>Ready for Release</strong>
							<small>Pickup notifications</small>
						</div>
					</article>
				</div>

				<section class="panel">
					<h2>SMS Notification Records</h2>
					<table>
						<thead>
							<tr>
								<th>Recipient</th>
								<th>Contact</th>
								<th>Type</th>
								<th>Message</th>
								<th>Status</th>
								<th>Date</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($rows as $r): ?>
								<tr>
									<td><?= htmlspecialchars($r['recipient_name']) ?></td>
									<td><?= htmlspecialchars($r['contact_no']) ?></td>
									<td><?= htmlspecialchars($r['notification_type']) ?></td>
									<td><?= htmlspecialchars($r['message']) ?></td>
									<td><?= $r['status'] ?></td>
									<td><?= $r['created_at'] ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</section>
			</section>
		</main>
	</div>
</body>
</html>