<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['payments_csrf'])) $_SESSION['payments_csrf'] = bin2hex(random_bytes(32));
function payEscape($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['payments_csrf'], (string)($_POST['csrf'] ?? ''))) {
        http_response_code(403); $error = 'Invalid security token. Refresh and try again.';
    } else {
        $action = (string)($_POST['action'] ?? '');
        try {
            if ($action === 'create') {
                $requestId = filter_var($_POST['request_id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
                $amount = trim((string)($_POST['amount'] ?? ''));
                $method = trim((string)($_POST['payment_method'] ?? ''));
                $transaction = trim((string)($_POST['transaction_no'] ?? ''));
                if (!$requestId || !preg_match('/^\d{1,8}(\.\d{1,2})?$/', $amount) || (float)$amount <= 0 || strlen($method)>50 || strlen($transaction)>100) throw new RuntimeException('Enter a valid request, positive amount, and appropriately sized payment details.');
                $exists = $pdo->prepare('SELECT id FROM certificate_requests WHERE id = ?');
                $exists->execute([$requestId]);
                if (!$exists->fetchColumn()) throw new RuntimeException('Certificate request not found.');
                $stmt = $pdo->prepare("INSERT INTO payments (request_id, amount, payment_method, transaction_no, status, paid_at) VALUES (?, ?, ?, ?, 'pending', NULL)");
                $stmt->execute([$requestId, $amount, $method ?: null, $transaction ?: null]);
                $_SESSION['payment_flash'] = 'Pending payment record created.';
            } elseif ($action === 'mark_failed') {
                $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
                if (!$id) throw new RuntimeException('Invalid payment ID.');
                $stmt = $pdo->prepare("UPDATE payments SET status = 'failed', paid_at = NULL WHERE id = ? AND status = 'pending'");
                $stmt->execute([$id]);
                if (!$stmt->rowCount()) throw new RuntimeException('Only pending payments can be marked failed.');
                $_SESSION['payment_flash'] = 'Payment marked failed.';
            } elseif ($action === 'confirm_manual') {
                $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
                if (!$id) throw new RuntimeException('Invalid payment ID.');
                $pdo->beginTransaction();
                $stmt = $pdo->prepare('SELECT status, payment_method FROM payments WHERE id = ? FOR UPDATE');
                $stmt->execute([$id]); $payment = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$payment || $payment['status'] !== 'pending') throw new RuntimeException('Only pending payments can be confirmed.');
                if (strtolower(trim((string)$payment['payment_method'])) !== 'cash') throw new RuntimeException('Only cash payments can be manually confirmed. Online payments require provider verification.');
                $stmt = $pdo->prepare("UPDATE payments SET status = 'paid', paid_at = NOW() WHERE id = ? AND status = 'pending'");
                $stmt->execute([$id]);
                $pdo->commit();
                $_SESSION['payment_flash'] = 'Cash receipt manually confirmed.';
            } else throw new RuntimeException('Unknown action.');
            header('Location: payments.php'); exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $e instanceof PDOException ? 'Database operation failed. Check the database constraints.' : $e->getMessage();
            if ($e instanceof PDOException) error_log($e->getMessage());
        }
    }
}
$flash = $_SESSION['payment_flash'] ?? '';
unset($_SESSION['payment_flash']);
$q = trim((string)($_GET['q'] ?? ''));
$status = (string)($_GET['status'] ?? 'all');
if (!in_array($status, ['all','pending','paid','failed'], true)) $status = 'all';
$sql = 'SELECT p.*, c.reference_no, r.full_name FROM payments p JOIN certificate_requests c ON c.id = p.request_id LEFT JOIN residents r ON r.id = c.resident_id WHERE 1=1';
$params = [];
if ($status !== 'all') { $sql .= ' AND p.status = ?'; $params[] = $status; }
if ($q !== '') { $sql .= ' AND (c.reference_no LIKE ? OR r.full_name LIKE ? OR p.transaction_no LIKE ?)'; $like = '%' . substr($q,0,100) . '%'; array_push($params,$like,$like,$like); }
$sql .= ' ORDER BY p.id DESC LIMIT 200';
$stmt = $pdo->prepare($sql); $stmt->execute($params); $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
$stats = $pdo->query("SELECT COUNT(*) total, COALESCE(SUM(CASE WHEN status='paid' THEN amount ELSE 0 END),0) received, SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) pending_count, SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) failed_count FROM payments")->fetch(PDO::FETCH_ASSOC);
$requests = $pdo->query('SELECT id, reference_no FROM certificate_requests ORDER BY id DESC LIMIT 200')->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>E-Payment | Barangay Management</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"><link rel="stylesheet" href="../assets/css/dashboard.css">
<link rel="stylesheet" href="../assets/css/topbar.css">
<style>
.payment-content{padding:28px 24px;min-width:0}.payment-header{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:22px}.payment-header h1{margin:0;color:#10234b}.payment-header p{color:#597098;margin:5px 0}.payment-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;margin-bottom:20px}.payment-card,.payment-panel{background:#fff;border:1px solid #e0e8f3;border-radius:13px;padding:20px}.payment-card small{display:block;color:#607395;margin-bottom:9px}.payment-card strong{font-size:26px;color:#12234b}.payment-panel{margin-bottom:20px}.payment-panel h2{font-size:18px;margin:0 0 16px}.payment-form{display:grid;grid-template-columns:2fr 1fr 1fr 1.5fr auto;gap:12px;align-items:end}.payment-form label{display:grid;gap:7px;color:#344563;font-size:13px}.payment-form input,.payment-form select,.payment-filter input,.payment-filter select{border:1px solid #cdd8e8;border-radius:8px;padding:11px;min-width:0;width:100%;background:#fff}.pay-btn{border:0;border-radius:8px;padding:11px 15px;background:#1177e8;color:white;cursor:pointer;font-weight:600}.pay-btn:disabled{opacity:.5}.payment-filter{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:15px}.payment-filter input{max-width:300px}.payment-filter select{max-width:150px}.payment-table-wrap{overflow-x:auto}.payment-table{width:100%;border-collapse:collapse;min-width:800px}.payment-table th,.payment-table td{text-align:left;padding:13px 10px;border-bottom:1px solid #e6edf6}.payment-table th{background:#f1f5fb;font-size:13px;color:#405477}.pay-status{padding:5px 9px;border-radius:20px;background:#edf1f6;font-size:12px}.pay-status.paid{background:#ddf8e9;color:#087a43}.pay-status.pending{background:#fff3d7;color:#956000}.pay-status.failed{background:#ffe3e3;color:#b32323}.payment-actions{display:flex;gap:6px;flex-wrap:wrap}.payment-actions button{font-size:12px;padding:7px 9px}.pay-danger{background:#d63e42}.pay-alert{padding:12px 16px;border-radius:8px;margin-bottom:16px;background:#e7f7ec;color:#116b38}.pay-alert.error{background:#fff0ef;color:#a31d24}.payment-note{color:#64748b;font-size:13px;margin-top:12px}@media(max-width:1050px){.payment-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.payment-form{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:600px){.payment-grid,.payment-form{grid-template-columns:1fr}.payment-content{padding:16px}}
</style></head><body><div class="app-layout">
<?php include __DIR__ . '/../includes/sidebar.php'; ?>
<div class="main-wrapper">
<?php
$pageTitle = 'E-Payment Management';
include __DIR__ . '/../includes/topbar.php';
?>
<main class="payment-content"><div class="payment-header"><div><h1>E-Payment</h1><p>Record, review and track certificate payments.</p></div></div>
<?php if ($flash): ?><div class="pay-alert"><?=payEscape($flash)?></div><?php endif; ?><?php if ($error): ?><div class="pay-alert error"><?=payEscape($error)?></div><?php endif; ?>
<section class="payment-grid"><div class="payment-card"><small>Total Records</small><strong><?=number_format((int)$stats['total'])?></strong></div><div class="payment-card"><small>Payments Received</small><strong>₱<?=number_format((float)$stats['received'],2)?></strong></div><div class="payment-card"><small>Pending</small><strong><?=number_format((int)$stats['pending_count'])?></strong></div><div class="payment-card"><small>Failed</small><strong><?=number_format((int)$stats['failed_count'])?></strong></div></section>
<section class="payment-panel"><h2>Record a Pending Payment</h2><form method="post" class="payment-form"><input type="hidden" name="csrf" value="<?=payEscape($_SESSION['payments_csrf'])?>"><input type="hidden" name="action" value="create"><label>Certificate Request<select name="request_id" required><option value="">Select request</option><?php foreach($requests as $r): ?><option value="<?=(int)$r['id']?>"><?=payEscape($r['reference_no'])?></option><?php endforeach; ?></select></label><label>Amount (₱)<input name="amount" type="number" step="0.01" min="0.01" max="99999999.99" required></label><label>Method<select name="payment_method" required><option value="Cash">Cash</option><option value="GCash">GCash</option><option value="Maya">Maya</option><option value="Bank Transfer">Bank Transfer</option></select></label><label>Transaction No.<input name="transaction_no" maxlength="100" placeholder="Optional reference"></label><button class="pay-btn" type="submit">Add Payment</button></form><p class="payment-note">New records are pending. Cash can be manually confirmed after receipt. Online payments must be verified by your payment provider before marking them paid.</p></section>
<section class="payment-panel"><h2>Payment Records</h2><form class="payment-filter" method="get"><input type="search" name="q" value="<?=payEscape($q)?>" placeholder="Search resident or reference"><select name="status"><option value="all">All statuses</option><?php foreach(['pending','paid','failed'] as $s): ?><option value="<?=$s?>" <?=$status===$s?'selected':''?>><?=ucfirst($s)?></option><?php endforeach; ?></select><button class="pay-btn" type="submit">Search</button><a href="payments.php" style="align-self:center">Reset</a></form><div class="payment-table-wrap"><table class="payment-table"><thead><tr><th>Payment ID</th><th>Request</th><th>Resident</th><th>Amount</th><th>Method</th><th>Transaction</th><th>Status</th><th>Paid At</th><th>Actions</th></tr></thead><tbody><?php if (!$rows): ?><tr><td colspan="9">No payment records found.</td></tr><?php endif; ?><?php foreach($rows as $p): ?><tr><td>#<?=(int)$p['id']?></td><td><?=payEscape($p['reference_no'])?></td><td><?=payEscape($p['full_name'])?></td><td>₱<?=number_format((float)$p['amount'],2)?></td><td><?=payEscape($p['payment_method'] ?: '—')?></td><td><?=payEscape($p['transaction_no'] ?: '—')?></td><td><span class="pay-status <?=payEscape($p['status'])?>"><?=payEscape(ucfirst($p['status']))?></span></td><td><?=payEscape($p['paid_at'] ?: '—')?></td><td><div class="payment-actions"><?php if($p['status']==='pending'): ?><?php if(strtolower(trim((string)$p['payment_method']))==='cash'): ?><form method="post" onsubmit="return confirm('Confirm that cash was actually received?')"><input type="hidden" name="csrf" value="<?=payEscape($_SESSION['payments_csrf'])?>"><input type="hidden" name="action" value="confirm_manual"><input type="hidden" name="id" value="<?=(int)$p['id']?>"><button class="pay-btn">Confirm Cash</button></form><?php endif; ?><form method="post" onsubmit="return confirm('Mark this pending payment as failed?')"><input type="hidden" name="csrf" value="<?=payEscape($_SESSION['payments_csrf'])?>"><input type="hidden" name="action" value="mark_failed"><input type="hidden" name="id" value="<?=(int)$p['id']?>"><button class="pay-btn pay-danger">Fail</button></form><?php endif; ?></div></td></tr><?php endforeach; ?></tbody></table></div></section></main></div></div><script src="../assets/js/topbar.js" defer></script>
</body></html>
