<?php
require '../includes/auth.php';
require '../config/database.php';

$st = $pdo->prepare('SELECT * FROM residents WHERE id = ?');
$st->execute([(int) ($_GET['id'] ?? 0)]);
$r = $st->fetch();

if (!$r) {
    http_response_code(404);
    die('Resident not found');
}

$tags = [];

foreach ([
    'senior_citizen' => 'Senior Citizen',
    'pwd' => 'PWD',
    'solo_parent' => 'Solo Parent',
    'four_ps' => '4Ps Beneficiary',
    'farmer' => 'Farmer',
] as $k => $v) {
    if ($r[$k]) {
        $tags[] = $v;
    }
}
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Resident Profile</title>
</head>
<body>
    <div class="app">
        <?php include '../includes/sidebar.php'; ?>

        <main class="content">
            <header class="top">
                <b>Resident Profile</b>
            </header>

            <section class="page">
                <a href="residents.php">← Back to Residents</a>

                <section class="panel profile">
                    <h1><?= htmlspecialchars($r['full_name']) ?></h1>
                    <p class="badge"><?= htmlspecialchars($r['resident_no']) ?></p>

                    <div class="details">
                        <?php foreach ([
                            'dob' => 'Date of Birth',
                            'sex' => 'Sex',
                            'civil_status' => 'Civil Status',
                            'address' => 'Address',
                            'contact_no' => 'Contact No.',
                            'household_no' => 'Household No.',
                            'household_info' => 'Household Information',
                            'occupation' => 'Occupation',
                        ] as $k => $v): ?>
                            <div>
                                <small><?= $v ?></small>
                                <b><?= htmlspecialchars($r[$k] ?: '—') ?></b>
                            </div>
                        <?php endforeach; ?>

                        <div>
                            <small>Classification / Sector</small>
                            <b><?= htmlspecialchars(implode(', ', $tags) ?: 'None') ?></b>
                        </div>
                    </div>

                    <a class="primary" href="residents.php?edit=<?= $r['id'] ?>">
                        Update Resident Record
                    </a>
                </section>
            </section>
        </main>
    </div>
</body>
</html>