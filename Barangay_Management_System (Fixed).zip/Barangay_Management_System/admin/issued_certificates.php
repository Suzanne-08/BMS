<?php

// Issuance & Records — compatible with the supplied issued_certificates schema.

require_once __DIR__ . '/../includes/auth.php';

require_once __DIR__ . '/../config/database.php';



if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }

if (empty($_SESSION['issuance_csrf'])) { $_SESSION['issuance_csrf'] = bin2hex(random_bytes(32)); }

function issueEsc($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

$base = '/Barangay_Management_System';

$adminName = $currentUser['full_name'] ?? $_SESSION['admin_name'] ?? 'Administrator';

$error = '';



if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['issuance_csrf'], (string)($_POST['csrf'] ?? ''))) {

        http_response_code(403); $error = 'Invalid security token. Refresh and try again.';

    } else {

        $action = (string)($_POST['action'] ?? '');

        $requestId = filter_var($_POST['request_id'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);

        if (!$requestId || !in_array($action, ['issue','release'], true)) {

            $error = 'Invalid action or request.';

        } else {

            try {

                $pdo->beginTransaction();

                $stmt = $pdo->prepare('SELECT id, status FROM certificate_requests WHERE id = ? FOR UPDATE');

                $stmt->execute([$requestId]);

                $request = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$request) { throw new RuntimeException('Request not found.'); }

                if ($action === 'issue') {

                    if ($request['status'] !== 'for_release') { throw new RuntimeException('Only requests marked For Release can be issued.'); }

                    $check = $pdo->prepare('SELECT id FROM issued_certificates WHERE request_id = ?');

                    $check->execute([$requestId]);

                    if ($check->fetchColumn()) { throw new RuntimeException('This request already has an issuance record.'); }

                    // Unique values are protected by database unique indexes.

                    $certificateNo = 'CERT-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(5)));

                    $token = bin2hex(random_bytes(32));

                    $adminId = (int)($_SESSION['admin_id'] ?? 0);

                    $stmt = $pdo->prepare('INSERT INTO issued_certificates (request_id, certificate_no, file_path, verification_token, issued_by, issued_at) VALUES (?, ?, NULL, ?, ?, NOW())');

                    $stmt->execute([$requestId, $certificateNo, $token, $adminId ?: null]);

                    $notice = 'Certificate issuance recorded. Certificate number: ' . $certificateNo;

                } else {

                    if ($request['status'] !== 'for_release') { throw new RuntimeException('Only For Release requests can be released.'); }

                    $stmt = $pdo->prepare('SELECT id, released_at FROM issued_certificates WHERE request_id = ? FOR UPDATE');

                    $stmt->execute([$requestId]);

                    $issued = $stmt->fetch(PDO::FETCH_ASSOC);

                    if (!$issued) { throw new RuntimeException('Create an issuance record before releasing.'); }

                    if ($issued['released_at'] !== null) { throw new RuntimeException('Certificate has already been released.'); }

                    $recipient = trim((string)($_POST['released_to'] ?? ''));

                    $remarks = trim((string)($_POST['release_remarks'] ?? ''));

                    if ($recipient === '' || mb_strlen($recipient) > 120 || mb_strlen($remarks) > 3000) { throw new RuntimeException('Enter a recipient (up to 120 characters) and remarks under 3000 characters.'); }

                    $stmt = $pdo->prepare('UPDATE issued_certificates SET released_at = NOW(), released_to = ?, release_remarks = ? WHERE id = ? AND released_at IS NULL');

                    $stmt->execute([$recipient, $remarks !== '' ? $remarks : null, $issued['id']]);

                    $stmt = $pdo->prepare("UPDATE certificate_requests SET status = 'released' WHERE id = ? AND status = 'for_release'");

                    $stmt->execute([$requestId]);

                    if ($stmt->rowCount() !== 1) { throw new RuntimeException('Request status changed. Please retry.'); }

                    $history = $pdo->prepare('INSERT INTO request_status_history

                        (request_id, old_status, new_status, remarks, changed_by, changed_at)

                        VALUES (?, ?, ?, ?, ?, NOW())');

                    $history->execute([

                        $requestId,

                        'for_release',

                        'released',

                        'Certificate physically released to ' . $recipient . ($remarks !== '' ? '. Remarks: ' . $remarks : '.'),

                        (int) $_SESSION['admin_id']

                    ]);

                    $notice = 'Certificate released successfully.';

                }

                $pdo->commit();

                $_SESSION['issuance_flash'] = $notice;

                header('Location: issued_certificates.php'); exit;

            } catch (Throwable $e) {

                if ($pdo->inTransaction()) { $pdo->rollBack(); }

                error_log('Issuance module: ' . $e->getMessage());

                $error = $e instanceof RuntimeException ? $e->getMessage() : 'Database operation failed. Check the PHP error log.';

            }

        }

    }

}

$success = $_SESSION['issuance_flash'] ?? '';

unset($_SESSION['issuance_flash']);

$q = trim((string)($_GET['q'] ?? ''));

$q = substr($q, 0, 100);

$search = '%' . $q . '%';

$stmt = $pdo->prepare("SELECT c.id AS request_id, c.reference_no, c.certificate_type, c.status, c.created_at, r.full_name, i.id AS issuance_id, i.certificate_no, i.issued_at, i.released_at, i.released_to, i.release_remarks

FROM certificate_requests c

INNER JOIN residents r ON r.id = c.resident_id

LEFT JOIN issued_certificates i ON i.request_id = c.id

WHERE (c.status IN ('for_release','released') OR i.id IS NOT NULL)

AND (c.reference_no LIKE ? OR r.full_name LIKE ? OR c.certificate_type LIKE ? OR COALESCE(i.certificate_no,'') LIKE ?)

ORDER BY COALESCE(i.issued_at, c.created_at) DESC, c.id DESC LIMIT 200");

$stmt->execute([$search,$search,$search,$search]);

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalIssued = (int)$pdo->query('SELECT COUNT(*) FROM issued_certificates')->fetchColumn();

$totalReleased = (int)$pdo->query('SELECT COUNT(*) FROM issued_certificates WHERE released_at IS NOT NULL')->fetchColumn();

$readyCount = (int)$pdo->query("SELECT COUNT(*) FROM certificate_requests c LEFT JOIN issued_certificates i ON i.request_id=c.id WHERE c.status='for_release' AND i.id IS NULL")->fetchColumn();

?>

<!doctype html>

<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">

<title>Issuance &amp; Records | Barangay Management</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<link rel="stylesheet" href="../assets/css/dashboard.css">
<link rel="stylesheet" href="../assets/css/topbar.css">

<style>

.issuance-panel{padding:22px}.issuance-tools{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:18px}.issuance-tools form{display:flex;gap:8px;flex-wrap:wrap}.issuance-tools input,.release-form input,.release-form textarea{border:1px solid #d7e0ee;border-radius:8px;padding:10px;font:inherit;max-width:100%}.issuance-tools button,.issue-btn,.release-form button{border:0;border-radius:8px;background:#0879ed;color:white;padding:10px 14px;cursor:pointer;font:inherit}.issue-btn{background:#168557}.release-form{display:flex;flex-direction:column;gap:7px;min-width:180px}.release-form textarea{resize:vertical}.release-form button{background:#0879ed}.issuance-table{width:100%;border-collapse:collapse;font-size:13px}.issuance-table th,.issuance-table td{text-align:left;padding:13px 10px;border-bottom:1px solid #e6ebf2;vertical-align:top}.issuance-table th{background:#f2f6fb;color:#344565}.table-responsive{overflow-x:auto}.status-chip{display:inline-block;padding:5px 9px;border-radius:20px;background:#eaf2ff;color:#1259a4;font-weight:600}.status-chip.released{background:#dcfce7;color:#166534}.notice{padding:12px 15px;border-radius:8px;margin:0 0 18px}.notice.success{background:#dcfce7;color:#166534}.notice.error{background:#fee2e2;color:#991b1b}.subtext{display:block;color:#64748b;font-size:12px;margin-top:5px}.empty-message{padding:18px;color:#64748b}.issuance-table td:last-child{min-width:210px}

</style></head><body>

<div class="app-layout">

<?php include __DIR__ . '/../includes/sidebar.php'; ?>

<div class="main-wrapper">

<?php $pageTitle = 'Issuance & Records'; include __DIR__ . '/../includes/topbar.php'; ?>

<main class="dashboard-content">

<div class="page-heading"><div><h1>Issuance &amp; Records</h1><p>Issue approved certificates and record their release to residents.</p></div></div>

<?php if ($success): ?><div class="notice success" role="status"><?=issueEsc($success)?></div><?php endif; ?>

<?php if ($error): ?><div class="notice error" role="alert"><?=issueEsc($error)?></div><?php endif; ?>

<section class="stats-grid">

<div class="stat-card"><div class="stat-icon blue"><i class="fa-solid fa-file-circle-check"></i></div><div class="stat-details"><h2><?=number_format($totalIssued)?></h2><p>Issued Certificates</p><small>All issuance records</small></div></div>

<div class="stat-card"><div class="stat-icon green"><i class="fa-solid fa-check-double"></i></div><div class="stat-details"><h2><?=number_format($totalReleased)?></h2><p>Released</p><small>Handed over to recipients</small></div></div>

<div class="stat-card"><div class="stat-icon orange"><i class="fa-solid fa-clock"></i></div><div class="stat-details"><h2><?=number_format($readyCount)?></h2><p>Ready for Issuance</p><small>Approved, not yet issued</small></div></div>

</section>

<section class="panel issuance-panel"><div class="issuance-tools"><h2>Certificate Records</h2><form method="get"><input type="search" name="q" value="<?=issueEsc($q)?>" placeholder="Search resident or certificate" aria-label="Search records"><button type="submit">Search</button></form></div>

<div class="table-responsive"><table class="issuance-table"><thead><tr><th>Reference / Certificate</th><th>Resident</th><th>Type</th><th>Status</th><th>Issued / Released</th><th>Actions</th></tr></thead><tbody>

<?php if (!$rows): ?><tr><td colspan="6" class="empty-message">No matching approved or issued certificate requests.</td></tr><?php endif; ?>

<?php foreach ($rows as $r): ?><tr>

<td><strong><?=issueEsc($r['reference_no'])?></strong><span class="subtext"><?=issueEsc($r['certificate_no'] ?? 'Not issued')?></span></td>

<td><?=issueEsc($r['full_name'])?></td><td><?=issueEsc($r['certificate_type'])?></td>

<td><span class="status-chip <?= $r['status']==='released' ? 'released' : '' ?>"><?=issueEsc(ucwords(str_replace('_',' ',$r['status'])))?></span></td>

<td><?=issueEsc($r['issued_at'] ?? '—')?><span class="subtext">Released: <?=issueEsc($r['released_at'] ?? '—')?></span></td>

<td>

<?php if (!$r['issuance_id'] && $r['status']==='for_release'): ?>

<form method="post"><input type="hidden" name="csrf" value="<?=issueEsc($_SESSION['issuance_csrf'])?>"><input type="hidden" name="action" value="issue"><input type="hidden" name="request_id" value="<?=(int)$r['request_id']?>"><button class="issue-btn" type="submit">Create Issuance</button></form>

<?php elseif ($r['issuance_id'] && !$r['released_at'] && $r['status']==='for_release'): ?>

<form method="post" class="release-form"><input type="hidden" name="csrf" value="<?=issueEsc($_SESSION['issuance_csrf'])?>"><input type="hidden" name="action" value="release"><input type="hidden" name="request_id" value="<?=(int)$r['request_id']?>"><input name="released_to" maxlength="120" required placeholder="Released to (name)" aria-label="Recipient name"><textarea name="release_remarks" maxlength="3000" rows="2" placeholder="Release remarks (optional)" aria-label="Release remarks"></textarea><button type="submit" onclick="return confirm('Confirm physical release of this certificate?')">Mark Released</button></form>

<?php elseif ($r['released_at']): ?><span class="subtext">Released to: <?=issueEsc($r['released_to'] ?? '—')?></span>

<?php else: ?><span class="subtext">No action available</span><?php endif; ?>

</td></tr><?php endforeach; ?>

</tbody></table></div></section>

</main></div></div>

<script src="../assets/js/topbar.js" defer></script>
</body></html>
