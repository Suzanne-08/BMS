<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';

require_once __DIR__ . '/../config/database.php';

// Verify PDO connection

if (!isset($pdo) || !($pdo instanceof PDO)) {

    exit('Database connection is not initialized.');

}

// -----------------------------

// Dashboard statistics

// -----------------------------

function scalarQuery(PDO $pdo, string $sql): float

{

    return (float) $pdo->query($sql)->fetchColumn();

}

$totalRequests = (int) scalarQuery(

    $pdo,

    "SELECT COUNT(*) FROM certificate_requests"

);

$issuedCertificates = (int) scalarQuery(

    $pdo,

    "SELECT COUNT(*) FROM issued_certificates"

);

$processingRequests = (int) scalarQuery(

    $pdo,

    "SELECT COUNT(*) FROM certificate_requests

     WHERE status = 'processing'"

);

$totalPayments = scalarQuery(

    $pdo,

    "SELECT COALESCE(SUM(amount), 0)

     FROM payments

     WHERE status = 'paid'"

);

// -----------------------------

// Request statuses

// -----------------------------

$statusRows = $pdo->query("

    SELECT status, COUNT(*) AS total

    FROM certificate_requests

    GROUP BY status

")->fetchAll();

$statusCounts = [

    'pending' => 0,

    'processing' => 0,

    'for_release' => 0,

    'released' => 0,

    'rejected' => 0

];

foreach ($statusRows as $row) {

    if (isset($statusCounts[$row['status']])) {

        $statusCounts[$row['status']] = (int) $row['total'];

    }

}

// -----------------------------

// Certificate requests chart

// -----------------------------

$period = $_GET['period'] ?? 'month';

if (!in_array($period, ['week', 'month', 'year', 'all'], true)) {

    $period = 'month';

}

$dateConditions = [

    'week' => "created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)",

    'month' => "created_at >= DATE_FORMAT(NOW(), '%Y-%m-01')

                AND created_at < DATE_FORMAT(

                    NOW() + INTERVAL 1 MONTH, '%Y-%m-01'

                )",

    'year' => "YEAR(created_at) = YEAR(NOW())",

    'all' => '1 = 1'

];

$dateCondition = $dateConditions[$period];

$chartStmt = $pdo->query("

    SELECT certificate_type, status, COUNT(*) AS total

    FROM certificate_requests

    WHERE $dateCondition

    GROUP BY certificate_type, status

    ORDER BY certificate_type

");

$chartRows = $chartStmt->fetchAll();

$certificateData = [];

foreach ($chartRows as $row) {

    $type = $row['certificate_type'];

    if (!isset($certificateData[$type])) {

        $certificateData[$type] = [

            'pending' => 0,

            'processing' => 0,

            'released' => 0,

            'other' => 0

        ];

    }

    $status = $row['status'];

    if (isset($certificateData[$type][$status])) {

        $certificateData[$type][$status] += (int) $row['total'];

    } else {

        $certificateData[$type]['other'] += (int) $row['total'];

    }

}

$chartLabels = array_keys($certificateData);

$chartPending = [];

$chartProcessing = [];

$chartReleased = [];

$chartOther = [];

foreach ($certificateData as $data) {

    $chartPending[] = $data['pending'];

    $chartProcessing[] = $data['processing'];

    $chartReleased[] = $data['released'];

    $chartOther[] = $data['other'];

}

// -----------------------------

// Payment method breakdown

// -----------------------------

$paymentRows = $pdo->query("

    SELECT

        COALESCE(NULLIF(TRIM(payment_method), ''), 'Unspecified')

            AS payment_method,

        SUM(amount) AS total

    FROM payments

    WHERE status = 'paid'

    GROUP BY payment_method

    ORDER BY total DESC

")->fetchAll();

$paymentLabels = [];

$paymentAmounts = [];

foreach ($paymentRows as $row) {

    $paymentLabels[] = $row['payment_method'];

    $paymentAmounts[] = (float) $row['total'];

}

// -----------------------------

// Recent activities

// -----------------------------

$activityStmt = $pdo->query("

    SELECT

        a.id,

        a.action,

        a.entity_type,

        a.details,

        a.created_at,

        u.full_name AS actor_name

    FROM activity_logs a

    LEFT JOIN users u ON u.id = a.user_id

    ORDER BY a.created_at DESC, a.id DESC

    LIMIT 5

");

$recentActivities = $activityStmt->fetchAll();

// -----------------------------

// Search

// -----------------------------

$search = trim((string) ($_GET['search'] ?? ''));

$searchResults = [];

if ($search !== '') {

    $search = mb_substr($search, 0, 100);

    $stmt = $pdo->prepare("

        SELECT

            cr.reference_no,

            cr.certificate_type,

            cr.status,

            r.full_name

        FROM certificate_requests cr

        INNER JOIN residents r

            ON r.id = cr.resident_id

        WHERE cr.reference_no LIKE ?

           OR cr.certificate_type LIKE ?

           OR r.full_name LIKE ?

           OR r.resident_no LIKE ?

        ORDER BY cr.created_at DESC

        LIMIT 20

    ");

    $term = '%' . $search . '%';

    $stmt->execute([$term, $term, $term, $term]);

    $searchResults = $stmt->fetchAll();

}

// -----------------------------

// Date

// -----------------------------

$currentDate = date('F j, Y');

$currentDay = date('l');

// Safe JSON encoding

function chartJson(array $data): string

{

    return json_encode(

        $data,

        JSON_HEX_TAG | JSON_HEX_AMP |

        JSON_HEX_APOS | JSON_HEX_QUOT

    ) ?: '[]';

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"

          content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard | Barangay Management</title>

    <link rel="stylesheet"

          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="stylesheet"

          href="../assets/css/dashboard.css">
    <link rel="stylesheet" href="../assets/css/topbar.css">
    <script src="../assets/js/topbar.js" defer></script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"

            defer></script>

    <script src="../assets/js/dashboard.js" defer></script>

</head>

<body>

<div class="app-layout">

    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <div class="main-wrapper">

        <?php
        $pageTitle = 'Dashboard';
        include __DIR__ . '/../includes/topbar.php';
        ?>

        <!-- DASHBOARD -->

        <main class="dashboard-content">

            <div class="page-heading">

                <div>

                    <h1>Dashboard</h1>

                    <p>

                        Welcome, <?= e($currentUser['full_name']) ?>!

                        Here's an overview of your barangay's transactions.

                    </p>

                </div>

                <div class="date-card">

                    <i class="fa-regular fa-calendar-days"></i>

                    <div>

                        <strong><?= e($currentDate) ?></strong>

                        <span><?= e($currentDay) ?></span>

                    </div>

                </div>

            </div>

            <?php if ($search !== ''): ?>

                <section class="panel search-results">

                    <div class="panel-heading">

                        <h2>Search Results</h2>

                        <a href="dashboard.php">Clear Search</a>

                    </div>

                    <?php if (empty($searchResults)): ?>

                        <p class="empty-message">

                            No matching certificate requests found.

                        </p>

                    <?php else: ?>

                        <div class="table-responsive">

                            <table>

                                <thead>

                                    <tr>

                                        <th>Reference No.</th>

                                        <th>Resident</th>

                                        <th>Certificate</th>

                                        <th>Status</th>

                                    </tr>

                                </thead>

                                <tbody>

                                    <?php foreach ($searchResults as $result): ?>

                                        <tr>

                                            <td><?= e($result['reference_no']) ?></td>

                                            <td><?= e($result['full_name']) ?></td>

                                            <td><?= e($result['certificate_type']) ?></td>

                                            <td>

                                                <?= e(ucwords(str_replace(

                                                    '_', ' ', $result['status']

                                                ))) ?>

                                            </td>

                                        </tr>

                                    <?php endforeach; ?>

                                </tbody>

                            </table>

                        </div>

                    <?php endif; ?>

                </section>

            <?php endif; ?>

            <!-- STATISTICS -->

            <section class="stats-grid">

                <div class="stat-card">

                    <div class="stat-icon blue">

                        <i class="fa-regular fa-file-lines"></i>

                    </div>

                    <div class="stat-details">

                        <h2><?= number_format($totalRequests) ?></h2>

                        <p>Total Requests</p>

                        <small>All recorded requests</small>

                    </div>

                </div>

                <div class="stat-card">

                    <div class="stat-icon green">

                        <i class="fa-solid fa-check"></i>

                    </div>

                    <div class="stat-details">

                        <h2><?= number_format($issuedCertificates) ?></h2>

                        <p>Certificates Issued</p>

                        <small>All issued certificates</small>

                    </div>

                </div>

                <div class="stat-card">

                    <div class="stat-icon orange">

                        <i class="fa-regular fa-clock"></i>

                    </div>

                    <div class="stat-details">

                        <h2><?= number_format($processingRequests) ?></h2>

                        <p>For Processing</p>

                        <small>Currently processing</small>

                    </div>

                </div>

                <div class="stat-card">

                    <div class="stat-icon purple">

                        <i class="fa-solid fa-peso-sign"></i>

                    </div>

                    <div class="stat-details">

                        <h2 class="payment-value">

                            ₱<?= number_format($totalPayments, 2) ?>

                        </h2>

                        <p>Payments Received</p>

                        <small>Successful payments only</small>

                    </div>

                </div>

            </section>

            <!-- MAIN CHART AND ACTIVITIES -->

            <section class="main-grid">

                <div class="panel certificate-panel">

                    <div class="panel-heading">

                        <h2>Certificate Requests</h2>

                        <form method="GET" action="dashboard.php">

                            <select name="period"

                                    aria-label="Chart period"

                                    onchange="this.form.submit()">

                                <option value="week"

                                    <?= $period === 'week' ? 'selected' : '' ?>>

                                    This Week

                                </option>

                                <option value="month"

                                    <?= $period === 'month' ? 'selected' : '' ?>>

                                    This Month

                                </option>

                                <option value="year"

                                    <?= $period === 'year' ? 'selected' : '' ?>>

                                    This Year

                                </option>

                                <option value="all"

                                    <?= $period === 'all' ? 'selected' : '' ?>>

                                    All Time

                                </option>

                            </select>

                        </form>

                    </div>

                    <div class="chart-container">

                        <canvas id="certificateChart"></canvas>

                    </div>

                </div>

                <div class="panel activities-panel">

                    <div class="panel-heading">

                        <h2>Recent Activities</h2>

                        <span class="panel-subtitle">Latest 5</span>

                    </div>

                    <div class="activities-list">

                        <?php if (empty($recentActivities)): ?>

                            <p class="empty-message">

                                No activities recorded yet.

                            </p>

                        <?php else: ?>

                            <?php foreach ($recentActivities as $activity): ?>

                                <div class="activity-item">

                                    <div class="activity-icon">

                                        <i class="fa-regular fa-file-lines"></i>

                                    </div>

                                    <div class="activity-details">

                                        <strong>

                                            <?= e($activity['action']) ?>

                                        </strong>

                                        <span>

                                            <?= e(

                                                $activity['actor_name']

                                                ?? 'System'

                                            ) ?>

                                            —

                                            <?= e($activity['entity_type']) ?>

                                        </span>

                                    </div>

                                    <time>

                                        <?= e(date(

                                            'M j, g:i A',

                                            strtotime($activity['created_at'])

                                        )) ?>

                                    </time>

                                </div>

                            <?php endforeach; ?>

                        <?php endif; ?>

                    </div>

                </div>

            </section>

            <!-- LOWER PANELS -->

            <section class="bottom-grid">

                <div class="panel">

                    <div class="panel-heading">

                        <h2>Request Status</h2>

                    </div>

                    <div class="donut-layout">

                        <div class="donut-chart">

                            <canvas id="statusChart"></canvas>

                            <div class="donut-center">

                                <strong>

                                    <?= number_format($totalRequests) ?>

                                </strong>

                                <small>Total Requests</small>

                            </div>

                        </div>

                        <div class="chart-legend">

                            <?php

                            $statusColors = [

                                'pending' => '#ffb400',

                                'processing' => '#1683ff',

                                'for_release' => '#8b5cf6',

                                'released' => '#22b573',

                                'rejected' => '#ef4444'

                            ];

                            foreach ($statusCounts as $status => $count):

                                $percentage = $totalRequests > 0

                                    ? ($count / $totalRequests) * 100

                                    : 0;

                            ?>

                                <div class="legend-row">

                                    <span class="legend-dot"

                                          style="background: <?= $statusColors[$status] ?>">

                                    </span>

                                    <span class="legend-name">

                                        <?= e(ucwords(str_replace('_', ' ', $status))) ?>

                                    </span>

                                    <strong>

                                        <?= $count ?>

                                        <small>

                                            (<?= number_format($percentage, 1) ?>%)

                                        </small>

                                    </strong>

                                </div>

                            <?php endforeach; ?>

                        </div>

                    </div>

                </div>

                <div class="panel">

                    <div class="panel-heading">

                        <h2>Payment Methods</h2>

                    </div>

                    <div class="donut-layout">

                        <div class="donut-chart">

                            <canvas id="paymentChart"></canvas>

                            <div class="donut-center">

                                <strong class="payment-center">

                                    ₱<?= number_format($totalPayments, 2) ?>

                                </strong>

                                <small>Total Payments</small>

                            </div>

                        </div>

                        <div class="chart-legend">

                            <?php if (empty($paymentRows)): ?>

                                <p class="empty-message">

                                    No successful payments yet.

                                </p>

                            <?php else: ?>

                                <?php

                                $colors = [

                                    '#1683ff', '#22b573',

                                    '#8b5cf6', '#ffb400',

                                    '#ef4444', '#06b6d4'

                                ];

                                foreach ($paymentRows as $i => $payment):

                                    $percentage = $totalPayments > 0

                                        ? ((float) $payment['total'] /

                                            $totalPayments) * 100

                                        : 0;

                                ?>

                                    <div class="legend-row">

                                        <span class="legend-dot"

                                              style="background: <?= $colors[$i % count($colors)] ?>">

                                        </span>

                                        <span class="legend-name">

                                            <?= e($payment['payment_method']) ?>

                                        </span>

                                        <strong>

                                            <?= number_format($percentage, 1) ?>%

                                        </strong>

                                    </div>

                                <?php endforeach; ?>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

                <div class="panel quick-actions-panel">

                    <div class="panel-heading">

                        <h2>Quick Actions</h2>

                    </div>

                    <div class="quick-actions-grid">

                        <a href="certificates.php"

                           class="quick-action">

                            <i class="fa-solid fa-file-circle-plus"></i>

                            <span>New Certificate Request</span>

                        </a>

                        <a href="residents.php"

                           class="quick-action">

                            <i class="fa-solid fa-users"></i>

                            <span>Add Resident</span>

                        </a>

                        <a href="payments.php"

                           class="quick-action">

                            <i class="fa-regular fa-credit-card"></i>

                            <span>Record Payment</span>

                        </a>

                        <a href="sms_notifications.php"

                           class="quick-action">

                            <i class="fa-solid fa-comment-sms"></i>

                            <span>Send SMS</span>

                        </a>

                        <a href="reports.php"

                           class="quick-action">

                            <i class="fa-solid fa-chart-simple"></i>

                            <span>View Reports</span>

                        </a>

                        <a href="tracking.php"

                           class="quick-action">

                            <i class="fa-solid fa-location-dot"></i>

                            <span>Track Request</span>

                        </a>

                    </div>

                </div>

            </section>

        </main>

    </div>

</div>

<script>

window.dashboardData = {

    certificate: {

        labels: <?= chartJson($chartLabels) ?>,

        pending: <?= chartJson($chartPending) ?>,

        processing: <?= chartJson($chartProcessing) ?>,

        released: <?= chartJson($chartReleased) ?>,

        other: <?= chartJson($chartOther) ?>

    },

    status: {

        labels: <?= chartJson(array_map(

            fn($s) => ucwords(str_replace('_', ' ', $s)),

            array_keys($statusCounts)

        )) ?>,

        values: <?= chartJson(array_values($statusCounts)) ?>

    },

    payments: {

        labels: <?= chartJson($paymentLabels) ?>,

        values: <?= chartJson($paymentAmounts) ?>

    }

};

</script>



</body>

</html>
