CREATE DATABASE IF NOT EXISTS barangay_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE barangay_system;
CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY,full_name VARCHAR(120) NOT NULL,username VARCHAR(60) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL,role ENUM('admin','staff','resident') NOT NULL DEFAULT 'resident',status ENUM('active','inactive') DEFAULT 'active',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS residents (id INT AUTO_INCREMENT PRIMARY KEY,resident_no VARCHAR(30) UNIQUE NOT NULL,full_name VARCHAR(120) NOT NULL,address VARCHAR(255),contact_no VARCHAR(30),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS certificate_requests (id INT AUTO_INCREMENT PRIMARY KEY,reference_no VARCHAR(40) UNIQUE NOT NULL,resident_id INT NOT NULL,certificate_type VARCHAR(100) NOT NULL,purpose VARCHAR(150),status ENUM('pending','processing','for_release','released','rejected') DEFAULT 'pending',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(resident_id) REFERENCES residents(id));
CREATE TABLE IF NOT EXISTS payments (id INT AUTO_INCREMENT PRIMARY KEY,request_id INT NOT NULL,amount DECIMAL(10,2) NOT NULL,payment_method VARCHAR(50),transaction_no VARCHAR(100),status ENUM('pending','paid','failed') DEFAULT 'pending',paid_at DATETIME NULL,FOREIGN KEY(request_id) REFERENCES certificate_requests(id));
INSERT IGNORE INTO residents(id,resident_no,full_name,address,contact_no) VALUES (1,'BRGY-RES-0001','Juan Dela Cruz','Sitio Maligaya, Barangay San Isidro','09171234567'),(2,'BRGY-RES-0002','Maria Santos','Sitio Maunlad, Barangay San Isidro','09187654321'),(3,'BRGY-RES-0003','Pedro Reyes','Sitio Pag-asa, Barangay San Isidro','09175554433');
INSERT IGNORE INTO certificate_requests(id,reference_no,resident_id,certificate_type,purpose,status) VALUES (1,'BRGY-2026-000123',1,'Barangay Clearance','Employment','processing'),(2,'IND-2026-000124',2,'Certificate of Indigency','Scholarship','released'),(3,'RES-2026-000125',3,'Residency Certificate','Bank Requirement','pending');
INSERT IGNORE INTO payments(id,request_id,amount,payment_method,transaction_no,status,paid_at) VALUES (1,1,50.00,'GCash','GC123456789','paid',NOW()),(2,2,50.00,'Maya','MY987654321','paid',NOW());

INSERT IGNORE INTO users(full_name,username,password,role,status) VALUES ('System Administrator','admin','$2y$12$pu5NJf0f322bPUjMUbv9tu7z12neZEE/LAs.uOMCgVI5E5ZwOwlT.','admin','active');

-- Expanded resident management fields
ALTER TABLE residents ADD COLUMN IF NOT EXISTS dob DATE NULL AFTER full_name;
ALTER TABLE residents ADD COLUMN IF NOT EXISTS sex ENUM('Male','Female','Other') NULL AFTER dob;
ALTER TABLE residents ADD COLUMN IF NOT EXISTS civil_status ENUM('Single','Married','Widow') NULL AFTER sex;
ALTER TABLE residents ADD COLUMN IF NOT EXISTS household_no VARCHAR(50) NULL AFTER contact_no;
ALTER TABLE residents ADD COLUMN IF NOT EXISTS household_info VARCHAR(255) NULL AFTER household_no;
ALTER TABLE residents ADD COLUMN IF NOT EXISTS occupation VARCHAR(120) NULL AFTER household_info;
ALTER TABLE residents ADD COLUMN IF NOT EXISTS senior_citizen TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE residents ADD COLUMN IF NOT EXISTS pwd TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE residents ADD COLUMN IF NOT EXISTS solo_parent TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE residents ADD COLUMN IF NOT EXISTS four_ps TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE residents ADD COLUMN IF NOT EXISTS farmer TINYINT(1) NOT NULL DEFAULT 0;

UPDATE residents SET dob='1955-04-12',sex='Male',civil_status='Married',household_no='HH-001',household_info='Head of household',occupation='Farmer',senior_citizen=1,farmer=1 WHERE id=1;
UPDATE residents SET dob='1988-08-23',sex='Female',civil_status='Single',household_no='HH-002',household_info='Household member',occupation='Vendor',solo_parent=1,four_ps=1 WHERE id=2;
UPDATE residents SET dob='1979-02-14',sex='Male',civil_status='Married',household_no='HH-003',household_info='Head of household',occupation='Farmer',farmer=1 WHERE id=3;

CREATE TABLE IF NOT EXISTS sms_notifications (
 id INT AUTO_INCREMENT PRIMARY KEY,
 resident_id INT NULL,
 request_id INT NULL,
 recipient_name VARCHAR(120) NOT NULL,
 contact_no VARCHAR(30) NOT NULL,
 notification_type ENUM('request_confirmation','processing_update','ready_for_release') NOT NULL,
 message VARCHAR(255) NOT NULL,
 status ENUM('queued','sent','failed') DEFAULT 'queued',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE SET NULL,
 FOREIGN KEY (request_id) REFERENCES certificate_requests(id) ON DELETE SET NULL
);
INSERT IGNORE INTO sms_notifications(id,resident_id,request_id,recipient_name,contact_no,notification_type,message,status) VALUES
(1,1,1,'Juan Dela Cruz','09171234567','request_confirmation','Your Barangay Clearance request has been received.','sent'),
(2,1,1,'Juan Dela Cruz','09171234567','processing_update','Your request is now being processed.','sent'),
(3,2,2,'Maria Santos','09187654321','ready_for_release','Your certificate is ready for release.','sent');
