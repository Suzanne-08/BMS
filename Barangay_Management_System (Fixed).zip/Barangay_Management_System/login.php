
<?php
session_start();
require __DIR__ . '/config/database.php';

if (!empty($_SESSION['admin_id'])) {
    header('Location: admin/dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? '');
    $p = $_POST['password'] ?? '';

    $s = $pdo->prepare(
        "SELECT * FROM users
         WHERE username = ?
         AND role = 'admin'
         AND status = 'active'
         LIMIT 1"
    );
    $s->execute([$u]);
    $row = $s->fetch();

    if ($row && password_verify($p, $row['password'])) {
        session_regenerate_id(true);
        $_SESSION['admin_id'] = $row['id'];
        $_SESSION['admin_name'] = $row['full_name'];

        header('Location: admin/dashboard.php');
        exit;
    }

    $error = 'Invalid username or password.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <title>Barangay Management System | Login</title>

    <link rel="stylesheet"
          href="assets/css/login.css">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>
<main class="login-page">

    <!-- LEFT SIDE -->
    <section class="welcome-panel">

        <div class="welcome-content">
            <img
                src="assets/images/barangay-logo.png"
                alt="Barangay Logo"
                class="welcome-logo">

            <h1>
                Barangay Management and
                Certificate Issuance System
            </h1>

            <h2>
                with SMS Notification, Tracking
                and E-Payment
            </h2>

            <p>
                A faster, easier, and more transparent
                way to serve a progressive barangay.
            </p>
        </div>

        <div class="features">
            <div class="feature">
                <div class="feature-icon blue">
                    <i class="fa-regular fa-file-lines"></i>
                </div>
                <h3>Online Requests</h3>
                <p>Apply for barangay certificates anytime, anywhere.</p>
            </div>

            <div class="feature">
                <div class="feature-icon green">
                    <i class="fa-regular fa-message"></i>
                </div>
                <h3>SMS Notifications</h3>
                <p>Get real-time updates on your requests.</p>
            </div>

            <div class="feature">
                <div class="feature-icon orange">
                    <i class="fa-solid fa-route"></i>
                </div>
                <h3>Request Tracking</h3>
                <p>Track your application status.</p>
            </div>

            <div class="feature">
                <div class="feature-icon purple">
                    <i class="fa-regular fa-credit-card"></i>
                </div>
                <h3>Secure E-Payment</h3>
                <p>Pay online for faster service.</p>
            </div>
        </div>

    </section>

    <!-- RIGHT SIDE -->
    <section class="login-panel">

        <div class="login-card">

            <img
                src="assets/images/barangay-logo.png"
                alt="Barangay Logo"
                class="login-logo">

            <h2>
                Barangay Management and
                Certificate Issuance System
            </h2>

            <p class="login-subtitle">
                with SMS Notification, Tracking and E-Payment
            </p>

            <?php if ($error): ?>
                <div class="error-message" role="alert">
                    <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">

                <div class="input-group">
                    <i class="fa-regular fa-user"></i>
                    <input
                        type="text"
                        name="username"
                        placeholder="Username"
                        aria-label="Username"
                        autocomplete="username"
                        required>
                </div>

                <div class="input-group">
                    <i class="fa-solid fa-lock"></i>

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="Password"
                        aria-label="Password"
                        autocomplete="current-password"
                        required>

                    <button
                        type="button"
                        class="toggle-password"
                        onclick="togglePassword()"
                        aria-label="Show or hide password">
                        <i class="fa-regular fa-eye"></i>
                    </button>
                </div>

                <div class="login-options">
                    <label>
                        <input type="checkbox" name="remember">
                        Remember me
                    </label>
                </div>

                <button type="submit" class="login-btn">
                    Login
                </button>

            </form>

            <div class="divider">
                <span>Barangay E-Services</span>
            </div>

            <p class="footer-text">
                Secure Administrator Access
            </p>

        </div>

    </section>

    <div class="bottom-wave"></div>

</main>

<script>
function togglePassword() {
    const input = document.getElementById('password');
    const icon = document.querySelector('.toggle-password i');

    const visible = input.type === 'password';
    input.type = visible ? 'text' : 'password';

    icon.className = visible
        ? 'fa-regular fa-eye-slash'
        : 'fa-regular fa-eye';
}
</script>
</body>
</html>
